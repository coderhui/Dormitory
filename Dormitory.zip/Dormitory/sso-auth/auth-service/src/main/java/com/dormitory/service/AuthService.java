package com.dormitory.service;

import com.dormitory.config.JwtProperties;
import com.dormitory.model.UserInfo;
import com.dormitory.pojo.SsUser;
import com.dormitory.utils.JwtUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AuthService {
    @Autowired
    private JwtProperties properties;

    public String login(SsUser user){
        try {
            String token = JwtUtils.generateToken(new UserInfo(Long.parseLong(user.getSsUid()+""), user.getSsUname()),
                    properties.getPrivateKey(), properties.getExpire());
            return token;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }
}
