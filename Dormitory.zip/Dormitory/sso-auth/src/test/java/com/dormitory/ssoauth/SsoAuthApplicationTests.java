package com.dormitory.ssoauth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SsoAuthApplicationTests {

    @Test
    void contextLoads() {
    }

}
