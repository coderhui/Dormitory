package com.dormitory.controller;

import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;
import com.dormitory.pojo.SsLeave;
import com.dormitory.pojo.SsUser;

@Controller
public class SsLeaveController_Consumer {
    private static final String REST_URL_PREFIX = "http://localhost:8001";
    
    @Autowired
    private RestTemplate restTemplate;
    
    @SuppressWarnings("unchecked")
    @RequestMapping("/user/leavelistteacher")//全查之离返日期降序,宿舍升序-→老师
	public String leaveselect(Model m) {
		List<SsLeave> leaves = restTemplate.getForObject(REST_URL_PREFIX + "/SsLeave/selLeaveandUserandDormByssLwdateDESCandssDname", List.class);
		m.addAttribute("leaves", leaves);
		return "system/SsLeave/LeaveList_teacher1";
	}
	
    @SuppressWarnings("unchecked")
	@RequestMapping("/user/leaveliststudent")//ssUid查,ss_Lwdate、ss_lbdate降序-→学生
	public String leaveselectstudent(HttpSession session,Model m) {
		SsUser user = (SsUser)session.getAttribute("user");
		int power = user.getSsPower();
		List<SsLeave> leaves = restTemplate.postForObject(REST_URL_PREFIX + "/SsLeave/selLeaveandUserandDormByssUidandsslwdateDESC", user.getSsUid(), List.class);
		m.addAttribute("leaves", leaves);
		if(power == 1) {
			return "system/SsLeave/LeaveList_sheyuan";//舍员
		}else {
			return "system/SsLeave/LeaveList_shezhang";//舍长
		}	
	}
    
    @SuppressWarnings("unchecked")
	@RequestMapping("/user/leaveselect")//搜索框ssUname、ssDname查
	public String leaveselect(Model m,String b) {
		List<SsLeave> leaves = restTemplate.postForObject(REST_URL_PREFIX + "/SsLeave/selLeaveandUserandDormByssUnameandssDname", b, List.class);
		m.addAttribute("leaves",leaves);
		return "system/SsLeave/LeaveList_teacher";
	}
	
	@RequestMapping("/user/leaveupdatesave")//改
	public String leaveupdatesave(int ssLid, Date ssLwdate, Date ssLbdate, String ssLstatus) {
		restTemplate.getForObject(REST_URL_PREFIX + "/SsLeave/UpdateLeave/"+ssLid+"/"+ssLwdate+"/"+ssLbdate+"/"+ssLstatus,int.class);
		return "redirect:leaveliststudent";
	}
	
	@RequestMapping("/user/leaveupdate")//ssLid查,进入改
	public String leaveupdate(Model m , int ssLid) {
		SsLeave updateleaves = restTemplate.postForObject(REST_URL_PREFIX + "/SsLeave/selLeaveandUserandDormByssLid",ssLid, SsLeave.class);
		m.addAttribute("updateleaves", updateleaves);
		return "system/SsLeave/LeaveEdit";
	}
	
	@RequestMapping("/user/leaveinsert")//进入加
	public String leaveinsert(Model m) {
		SsLeave insertssleaves = new SsLeave();
		m.addAttribute("insertssleaves", insertssleaves);
		return "system/SsLeave/LeaveInsert";
	}
	  	  
	@RequestMapping("/user/leaveinsertsave")//加
	public String leaveinsertsave(Date ssLwdate,Date ssLbdate,String ssLstatus,HttpSession session) {
		SsUser user = (SsUser)session.getAttribute("user");
		SsLeave ssleave = new SsLeave();
		ssleave.setSsUid(user.getSsUid());
		ssleave.setSsLwdate(ssLwdate);
		ssleave.setSsLbdate(ssLbdate);
		ssleave.setSsLstatus(ssLstatus);
		restTemplate.postForObject(REST_URL_PREFIX + "/SsLeave/insertSelective", ssleave, int.class);
		return "redirect:leaveliststudent";
	}

}
