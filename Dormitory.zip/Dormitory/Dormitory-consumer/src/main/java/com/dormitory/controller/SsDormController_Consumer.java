package com.dormitory.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSONObject;
import com.dormitory.pojo.SsUser;
@Controller
public class SsDormController_Consumer {
    private static final String REST_URL_PREFIX = "http://localhost:8001";
    
    private static final String URL = "system/SsDorm/";
    
    @Autowired
    private RestTemplate restTemplate;
    
    @SuppressWarnings("unchecked")
	@RequestMapping("/user/TeacherToDorm")
	public String teacherToDorm(Model m) {//跳转到宿舍界面
		List<SsUser> list = restTemplate.getForObject(REST_URL_PREFIX + "/SsDorm/FindAllUserAndDormMes", List.class);
		m.addAttribute("list",list);
		return URL+"dorm";
	}
    
    @SuppressWarnings("unchecked")
    @RequestMapping("/user/ChangeShezhang")
	public String ChangeShezhang(Model m,int ssDid) {//跳转更换舍长界面
		List<SsUser> list = restTemplate.postForObject(REST_URL_PREFIX + "/SsDorm/FindUserAndDormMesByDid", ssDid, List.class);
		m.addAttribute("list",list);
		//int did =list.get(0).getSsDid();
		m.addAttribute("did",ssDid);
		return URL+"ChangeShezhang";
	}
    
    @RequestMapping("/changeShezhangCheck")
	@ResponseBody
	public String changeShezhangCheck(@RequestBody String mes) {//验证输入的人是否存在于该宿舍
		JSONObject json = JSONObject.parseObject(mes);
		Integer ssDid = json.getInteger("ssDid");
		String ssUname = json.getString("ssUname");	
		SsUser user = restTemplate.postForObject(REST_URL_PREFIX + "/SsDorm/FindUserByUname", ssUname, SsUser.class);
		if(user.getSsDid() == ssDid) {
			return "{\"flag\":\"1\"}";//输入的人是该宿舍的
		}
		return "{\"flag\":\"0\"}";//输入的人不是该宿舍的
	}
    
    @PostMapping("/ChangeShezhangSave")
	@ResponseBody
	public String ChangeShezhangSave(@RequestBody String mes) {//保存修改舍长
		JSONObject json = JSONObject.parseObject(mes);
		Integer ssDid = json.getInteger("ssDid");
		String ssUname = json.getString("ssUname");
		restTemplate.getForObject(REST_URL_PREFIX + "/SsDorm/UpdateShezhang/"+ssUname+"/"+ssDid, boolean.class);
		return "{\"flag\":\""+ssUname+"\"}";
	}
}
