package com.dormitory.handler;

import com.dormitory.feign.UserFeignClient;
import com.dormitory.pojo.SsUser;
import org.springframework.stereotype.Component;

@Component
public class UserFeignClientHandler implements UserFeignClient {

    @Override
    public SsUser findAll() {
        return null;
    }
}
