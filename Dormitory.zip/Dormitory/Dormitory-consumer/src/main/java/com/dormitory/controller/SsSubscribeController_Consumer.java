package com.dormitory.controller;

import javax.servlet.http.HttpSession;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSONObject;
import com.dormitory.pojo.SsSubscribe;
import com.dormitory.pojo.SsUser;

import coms.Commons;
@Controller
public class SsSubscribeController_Consumer {
    private static final String REST_URL_PREFIX = "http://localhost:8001";
    
    private static final String URL = "system/SsSubscribe/";
    
    @Autowired
    private RestTemplate restTemplate;
    
    @RequestMapping("/user/toSubscribe")
	public String toSubscribe(Model m,HttpSession session) {//跳去买水界面
		SsUser user = (SsUser)session.getAttribute("user");
		SsUser user2 = restTemplate.postForObject(REST_URL_PREFIX + "/SsSubscribe/FindUserAllMes", user.getSsUid(), SsUser.class);
		m.addAttribute("water_price", Commons.water_price);
		m.addAttribute("water_to", Commons.water_to_price);
		m.addAttribute("user",user2);
		return URL+"BuyWater";
	}
    
    @RequestMapping("/subscribe")
	@ResponseBody
	public String subscribe(@RequestBody String mes) {//买水
		JSONObject json = JSONObject.parseObject(mes);
		Integer ssUid = json.getInteger("ssUid");
		Integer to = json.getInteger("to");
		SsUser user = restTemplate.postForObject(REST_URL_PREFIX + "/SsSubscribe/FindUserAllMes", ssUid, SsUser.class);
		if(to == 1) {
			//上门
			if(user.getSsMoney() >= Commons.water_price + Commons.water_to_price) {//判断是否够钱
				restTemplate.postForObject(REST_URL_PREFIX + "/SsSubscribe/BuyWaterAndTo", ssUid, boolean.class);
				SsUser user2 = restTemplate.postForObject(REST_URL_PREFIX + "/SsSubscribe/FindUserAllMes", ssUid, SsUser.class);
				Double money = user2.getSsMoney();
				return "{\"flag\":\"2\",\"money\":\""+money+"\"}";
			}
		}else {//不上门
			if(user.getSsMoney() >= Commons.water_price) {//判断是否够钱
				restTemplate.postForObject(REST_URL_PREFIX + "/SsSubscribe/BuyWater", ssUid, boolean.class);
				SsUser user2 = restTemplate.postForObject(REST_URL_PREFIX + "/SsSubscribe/FindUserAllMes", ssUid, SsUser.class);
				Double money = user2.getSsMoney();
				return "{\"flag\":\"1\",\"money\":\""+money+"\"}";
			}
		}
		SsUser user2 = restTemplate.postForObject(REST_URL_PREFIX + "/SsSubscribe/FindUserAllMes", ssUid, SsUser.class);
		Double money = user2.getSsMoney();
		return "{\"flag\":\"0\",\"money\":\""+money+"\"}";
	}
    
    @SuppressWarnings("unchecked")
    @RequestMapping("/user/toteacherWater")
    public String toteacherWater(Model m) {
    	List<SsSubscribe> list = restTemplate.getForObject(REST_URL_PREFIX + "/SsSubscribe/FindAllSubscribe", List.class);
    	m.addAttribute("list",list);
    	return URL+"teacherWater1";
    }
    
    @RequestMapping("/user/updateSsStatus")
    public String updateSsStatus(int ssSid) {
    	String status = "已送达";
    	restTemplate.getForObject(REST_URL_PREFIX + "/SsSubscribe/UpdateSsStatus/"+ssSid+"/"+status, int.class);
    	return "redirect:toteacherWater";
    }
}
