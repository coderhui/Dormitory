package com.dormitory.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dormitory.feign.AuthFeignClient;
import com.dormitory.util.CookieUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSONObject;
import com.dormitory.pojo.SsDorm;
import com.dormitory.pojo.SsRepair;
import com.dormitory.pojo.SsUser;
import com.dormitory.pojo.SsViolation;

@Controller
public class SsUserController_Consumer {
    private static final String REST_URL_PREFIX = "http://localhost:8001";
    
    private static final String URL = "system/SsUser/";
    
    @Autowired
    private RestTemplate restTemplate;

    @Autowired
	private AuthFeignClient authFeignClient;
    
    @RequestMapping("/user/index")
	public String index() {//跳转登陆界面
		return "index";
	}
    
    @PostMapping("/check")
	public @ResponseBody String Check(@RequestBody String mes) {//判断密码是否正确
		JSONObject object = JSONObject.parseObject(mes);
		String username = object.getString("username");
		String password = object.getString("password");
		SsUser user = new SsUser();
		user.setSsUname(username);
		user.setSsPassword(password);
		if(restTemplate.postForObject(REST_URL_PREFIX + "/SsUser/usernameCheck",username, boolean.class)) {//判断用户名是否存在
			if(restTemplate.postForObject(REST_URL_PREFIX + "/SsUser/passwordCheck",user, boolean.class)) {////判断密码是否正确
				authFeignClient.login(user);
				String status = "{\"status\":\"1\"}";
				return status;
			}else {//密码错误
				String status = "{\"status\":\"2\"}";
				return status;
			}
		}else {//用户不存在
			String status = "{\"status\":\"0\"}";
			return status;
		}
	}
    
    @PostMapping("/user/login")
	public String Login(String username,String password,HttpSession session) {//登陆
		System.out.println(username+"   "+password);
		//SsUser user2 = new SsUser();
		//user2.setSsUname(username);
		//user2.setSsPassword(password);
		SsUser user = restTemplate.getForObject(REST_URL_PREFIX + "/SsUser/FindUserByNameAndPw/"+username+"/"+password, SsUser.class);
		int power = user.getSsPower();
		System.out.println("权限:"+user.getSsPower());
		if(power != 0) {
			session.setAttribute("user", user);
			if(power == 3) {//判断是否为宿管
				return "redirect:toteacher";
			}
			return "redirect:tosheyuan";
		}
		return "redirect:index";
	}
    
    @RequestMapping("/user/tosheyuan")
	public String tosheyuan(Model m,HttpSession session) {//去舍员界面
		SsUser user = (SsUser)session.getAttribute("user");
		m.addAttribute("user",user);
		return URL+"sheyuan";
	}
    
    @SuppressWarnings("unchecked")
    @GetMapping("/user/toteacher")
	public String toteacher(Model m) {//去宿管界面
		List<SsDorm> list = restTemplate.getForObject(REST_URL_PREFIX + "/SsUser/FindAllDorm", List.class);
		m.addAttribute("Dormcount",list.size());
		List<SsUser> list2 = restTemplate.getForObject(REST_URL_PREFIX + "/SsUser/FindAllUserMes", List.class);
		m.addAttribute("Usercount",list2.size());
		List<SsRepair> list3 = restTemplate.getForObject(REST_URL_PREFIX + "/SsUser/FindAllRepairMes", List.class);
		m.addAttribute("Repaircount",list3.size());
		List<SsViolation> list4 = restTemplate.getForObject(REST_URL_PREFIX + "/SsUser/FindAllViolationMes", List.class);
		m.addAttribute("Violationcount",list4.size());
		return URL+"teacher1";
	}
    
    @RequestMapping("/user/toregister")
	public String toRegister() {//跳转注册
		return "register";
	}
    
    @PostMapping("/send")
	public @ResponseBody String sendEmail(@RequestBody String Eml,HttpSession session) {//发送邮箱验证码
		System.out.println(Eml); 
		JSONObject object = JSONObject.parseObject(Eml);//将json格式的字符串转为json对象
		String email = object.getString("Eml");//取出eml的值
		System.out.println("邮箱:"+email);
		SsUser user = new SsUser();
		user.setSsEmail(email);
		String code = restTemplate.postForObject(REST_URL_PREFIX + "/SsUser/sendSimpleEmail",user, String.class);
		System.out.println(code);
		String jsoncode = "{\"code\":\""+code+"\"}";
		return jsoncode;
	} 
    
	@RequestMapping("/register_username_check")
	@ResponseBody
	public String register_username_check(@RequestBody String mes) {//验证用户名是否已存在
		JSONObject json = JSONObject.parseObject(mes);
		String ssUname = json.getString("ssUname");
		boolean flag = restTemplate.postForObject(REST_URL_PREFIX + "/SsUser/usernameCheck",ssUname, boolean.class);
		if(flag) {//判断用户名是否存在
			//存在
			return "{\"flag\":\"1\"}";
		}else {//不存在
			return "{\"flag\":\"0\"}";
		}
	}
    
    @RequestMapping("/user/register")
	public String Register(SsUser user) {//注册
		System.out.println(user.toString());
		restTemplate.postForObject(REST_URL_PREFIX + "/SsUser/addUser", user, boolean.class);
		return "redirect:index";
	}
    
    @RequestMapping("/user/toFindPw")
	public String ToFindPw() {//跳转到找回密码界面
		return URL+"findPassword";
	}
    
    @RequestMapping("/sendEmail_findPw")
	public @ResponseBody String sendEmailFindPw(@RequestBody SsUser user) {//发送邮件找回密码
		if(restTemplate.postForObject(REST_URL_PREFIX + "/SsUser/usernameCheck",user.getSsUname(), boolean.class)) {//判断用户名是否存在
			if(restTemplate.postForObject(REST_URL_PREFIX + "/SsUser/checkEmail", user, boolean.class)) {//判断邮箱是否正确
				restTemplate.postForObject(REST_URL_PREFIX + "/SsUser/sendPassword", user, boolean.class);
				String json = "{\"status\":\"2\"}";
				return json;
			}
			String json = "{\"status\":\"1\"}";
			return json;
		}
		String json = "{\"status\":\"0\"}";
		return json;
	}
    
    @RequestMapping("/user/toRecharge")
	public String toRecharge() {//去充值界面
		return URL+"recharger";
	}
    
    @RequestMapping("/user/recharge")
	public String Recharger(double ssMoney,HttpSession session) {//充值
		SsUser user = (SsUser)session.getAttribute("user");
		user.setSsMoney(user.getSsMoney() + ssMoney);
		restTemplate.postForObject(REST_URL_PREFIX + "/SsUser/recharge", user, boolean.class);
		return "redirect:tosheyuan";
	}
    
    @RequestMapping("/user/loginOut")
	public String loginOut(HttpServletRequest request, HttpServletResponse response, HttpSession session) {//注销
		session.invalidate();
		CookieUtils.deleteCookie(request,response,"dormitory_token");
		return "redirect:index";
	}
    
    @SuppressWarnings("unchecked")
    @RequestMapping("/user/TeacherToUser")
	public String teacherToUser(Model m) {//宿管跳转到查看用户界面
		List<SsUser> list = restTemplate.getForObject(REST_URL_PREFIX + "/SsUser/FindAllUserMes", List.class);
		m.addAttribute("list",list);
		return URL+"teacherToUser";
	}
    
    @RequestMapping("/user/findUserMes")
	public String FindUserMes(Model m,HttpSession session) {//跳转用户信息界面
		SsUser user = (SsUser)session.getAttribute("user");
		SsUser mes = restTemplate.postForObject(REST_URL_PREFIX + "/SsUser/FindUserAllMes", user.getSsUid(), SsUser.class);
		m.addAttribute("mes",mes);
		return URL+"userMes";
	}
    
	@RequestMapping("/user/userUpdateMes")
	public String UserUpdateMes(Model m,HttpSession session) {//跳转用户修改界面
		SsUser user = (SsUser)session.getAttribute("user");
		SsUser mes = restTemplate.postForObject(REST_URL_PREFIX + "/SsUser/FindUserAllMes", user.getSsUid(), SsUser.class);
		m.addAttribute("mes",mes);
		return URL+"userUpdateMes";
	}
	
	@RequestMapping("/user/updateMesSave")
	public String UpdateMesSave(SsUser user){//保存修改信息
		restTemplate.postForObject(REST_URL_PREFIX + "/SsUser/recharge", user, boolean.class);
		return "redirect:findUserMes";
	}

}
