package com.dormitory.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.dormitory.pojo.SsHygiene;
import com.dormitory.pojo.SsUser;
@Controller
public class SsHygieneController_Consumer {
    private static final String REST_URL_PREFIX = "http://localhost:8001";
    
    @Autowired
    private RestTemplate restTemplate;
    
    @SuppressWarnings("unchecked")
    @RequestMapping("/user/hygienelistteacher")//全查之时间降序,宿舍升序--→老师
	public String hygienelistteacher(Model m) {
		List<SsHygiene> hygienes = restTemplate.getForObject(REST_URL_PREFIX + "/SsHygiene/selHygieneandDormandUserByssHdateDESCandssDname", List.class);
		m.addAttribute("hygienes", hygienes);
		return "system/SsHygiene/HygieneList_teacher1";
	}
	
    @SuppressWarnings("unchecked")
	@RequestMapping("/user/hygieneliststudent")//ssDid查,日期降序-→学生
	public String hygieneliststudent(HttpSession session,Model m) {
		SsUser user = (SsUser)session.getAttribute("user");
		int power = user.getSsPower();
		List<SsHygiene> hygienes = restTemplate.postForObject(REST_URL_PREFIX + "/SsHygiene/selHygieneandDormandUserByssDidandssHdateDESC", user.getSsUid(), List.class);
		m.addAttribute("hygienes", hygienes);
		if(power == 1) {
			return "system/SsHygiene/HygieneList_sheyuan";//舍员
		}else {
			return "system/SsHygiene/HygieneList_shezhang";//舍长
		}	
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping("/user/hygieneselect")//搜索框ssDname查
	public String hygieneselect(Model m,String s) {
		List<SsHygiene> hygienes = restTemplate.postForObject(REST_URL_PREFIX + "/SsHygiene/selHygieneandDormandUserByssDname", s, List.class);
		m.addAttribute("hygienes",hygienes);
		return "system/SsHygiene/HygieneList_teacher";
	}
	
	@RequestMapping("/user/hygienedelete")//删
	public String hygienedelete(int ssHid) {
		restTemplate.postForObject(REST_URL_PREFIX + "/SsHygiene/deletehygiene",ssHid, int.class);
		return "redirect:hygienelistteacher";
	}
	
	//(int ssHid,String ssDname,int ssBed,int ssCh,int ssYt,int ssWc,int ssWs,int ssHnum,Date ssHdate)
	@RequestMapping("/user/hygieneupdatesave")//改
	public String hygieneupdatesave(SsHygiene sshygiene,String ssDname) {
		sshygiene.setSsHnum(sshygiene.getSsWc()+sshygiene.getSsBed()+sshygiene.getSsCh()+sshygiene.getSsWs()+sshygiene.getSsYt());//总分
		restTemplate.postForObject(REST_URL_PREFIX + "/SsHygiene/updateByssHid/"+ssDname,sshygiene,int.class);
		return "redirect:hygienelistteacher";
	}
	
	@RequestMapping("/user/hygieneupdate")//ssHid查,进入改
	public String hygieneupdate(Model m , int ssHid) {
		SsHygiene updatehygienes = restTemplate.postForObject(REST_URL_PREFIX + "/SsHygiene/selHygieneandDormByssHid",ssHid, SsHygiene.class);
		m.addAttribute("updatehygienes", updatehygienes);
		return "system/SsHygiene/HygieneEdit";
	}
	
	@RequestMapping("/user/hygieneinsert")
	public String hygieneinsert() {//增加
		System.out.println("1222222222");
		restTemplate.getForObject(REST_URL_PREFIX + "/SsHygiene/InsertHy", boolean.class);
		return "redirect:hygienelistteacher";
	}

}
