package com.dormitory.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.dormitory.pojo.SsNotice;
import com.dormitory.pojo.SsUser;

@Controller
public class SsNoticeController_Consumer {
    private static final String REST_URL_PREFIX = "http://localhost:8001";
    
    @Autowired
    private RestTemplate restTemplate;
    
    @SuppressWarnings("unchecked")//告诉编译器忽略 unchecked 警告信息，如使用List，ArrayList等未进行参数化产生的警告信息
    @RequestMapping("/user/noticelist")//全查之时间降序
	public String notcieselect(Model m,HttpSession session) {
		SsUser user = (SsUser)session.getAttribute("user");
		int power = user.getSsPower();
		List<SsNotice> notices =  restTemplate.getForObject(REST_URL_PREFIX + "/SsNotice/selectByssNdateDESC", List.class);
		m.addAttribute("notices", notices);//"notices"→${notices}
		if(power == 3) {
			return "system/SsNotice/NoticeList_teacher1";//老师
		}
		if(power == 2) {
			return "system/SsNotice/NoticeList_shezhang";//舍长
		}
		else {
			return "system/SsNotice/NoticeList_sheyuan";//舍员
		}	
	}
	
	@RequestMapping("/user/noticedelete")//删
	public String noticedelete(int ssNid) {//用int，别用Integer
		restTemplate.postForObject(REST_URL_PREFIX + "/SsNotice/deletenotice",ssNid, int.class);
		return "redirect:noticelist";
	}
	
	@RequestMapping("/user/noticeupdatesave")//改
	public String noticeupdatesave(SsNotice record) {
		restTemplate.postForObject(REST_URL_PREFIX + "/SsNotice/updateByssNid", record, int.class);
		return "redirect:noticelist";
	}
	
	@RequestMapping("/user/noticeupdate")//ssNid查,进入改
	public String noticeupdate(Model m , int ssNid) {
		SsNotice updatenotices = restTemplate.postForObject(REST_URL_PREFIX + "/SsNotice/selectByssNid", ssNid, SsNotice.class);
		m.addAttribute("updatenotices", updatenotices);
		return "system/SsNotice/NoticeEdit";
	}
	
	@RequestMapping("/user/noticeinsertsave")//加
	public String noticeinsertsave(SsNotice record,String time) throws ParseException {
		Date ssndate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(time);//String转换成Date-→parse;name="time"
		record.setSsNdate(ssndate);
		restTemplate.postForObject(REST_URL_PREFIX + "/SsNotice/insertnotice", record, int.class);
		return "redirect:noticelist";
	}
	
	@RequestMapping("/user/noticeinsert")//进入加
	public String noticeinsert(Model m) {
		SsNotice insertnotices = new SsNotice();
		insertnotices.setSsNdate(new Date());//换取系统时间
		String ssndate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());//Date转换成String-→format
		m.addAttribute("ssndate",ssndate);//th:value="${ssndate}
		m.addAttribute("insertnotices", insertnotices);
		return "system/SsNotice/NoticeInsert";
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping("/user/noticemohu")//搜索框内容模糊查
	public String noticemohu(Model m,String q,HttpSession session) {
		SsUser user = (SsUser)session.getAttribute("user");
		int power = user.getSsPower();
		List<SsNotice> notices = restTemplate.postForObject(REST_URL_PREFIX + "/SsNotice/selectnotciemohu", q, List.class);
		m.addAttribute("notices",notices);
		if(power == 3) {
			return "system/SsNotice/NoticeList_teacher";//老师
		}
		if(power == 2) {
			return "system/SsNotice/NoticeList_shezhang";//舍长
		}
		else {
			return "system/SsNotice/NoticeList_sheyuan";//舍员
		}	
	}
	
	 @RequestMapping("/user/index1")
		public String index() {//跳转登陆界面
			return "index1";
		}
	
//	@SuppressWarnings("unchecked")
//	@RequestMapping("/user/noticemohu")//搜索框内容模糊查
//	public String noticemohu(Model m,SsNotice ssnotice,HttpSession session) {
//		SsUser user = (SsUser)session.getAttribute("user");
//		int power = user.getSsPower();
//		List<SsNotice> notices = restTemplate.postForObject(REST_URL_PREFIX + "/SsNotice/selectnotciemohu", ssnotice, List.class);
//		m.addAttribute("notices",notices);
//		if(power == 3) {
//			return "system/SsNotice/NoticeList_teacher";//老师
//		}
//		if(power == 2) {
//			return "system/SsNotice/NoticeList_shezhang";//舍长
//		}
//		else {
//			return "system/SsNotice/NoticeList_sheyuan";//舍员
//		}	
//	}

}
