package com.dormitory.feign;

import com.dormitory.pojo.SsUser;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@FeignClient("auth-service")
public interface AuthFeignClient {
    @GetMapping("/auth/login")
    public ResponseEntity<Void> login(@RequestBody SsUser user);
}
