package com.dormitory.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.dormitory.pojo.SsUser;
import com.dormitory.pojo.SsViolation;
@Controller
public class SsViolationController_Consumer {
    private static final String REST_URL_PREFIX = "http://localhost:8001";
    
    private static final String URL = "system/SsViolation/";
    
    @Autowired
    private RestTemplate restTemplate;
    
    @SuppressWarnings("unchecked")
    @RequestMapping("/user/findViolation")
	public String findViolation(HttpSession session,Model m) {//舍员去违规记录界面
		SsUser user = (SsUser)session.getAttribute("user");
		List<SsViolation> list = restTemplate.postForObject(REST_URL_PREFIX + "/SsViolation/FindViolationMesByUid", user.getSsUid(), List.class);
		m.addAttribute("violation",list);
		return URL+"student_violation";
	}
    
    @RequestMapping("/user/violation_student_laogai")
	public String applylaogai(Integer ssVid) {//学生申请劳改
		String state = "劳改审核中";
		restTemplate.getForObject(REST_URL_PREFIX + "/SsViolation/UpdateViolationState/"+ssVid+"/"+state, int.class);
		return "redirect:findViolation";
	}
    
    @RequestMapping("/user/violation_student_zhuxiao")
	public String applyzhuxiao(Integer ssVid) {//学生申请注销
		String state = "注销申请中";
		restTemplate.getForObject(REST_URL_PREFIX + "/SsViolation/UpdateViolationState/"+ssVid+"/"+state, int.class);
		return "redirect:findViolation";
	}
    
    @SuppressWarnings("unchecked")
    @RequestMapping("/user/TeacherToViolation")
	public String TeacherToViolation(Model m) {//宿管去违规管理界面
		List<SsViolation> list = restTemplate.getForObject(REST_URL_PREFIX + "/SsViolation/FindAllViolationMes", List.class);
		m.addAttribute("violation",list);
		return URL+"teacher_violation1";
	}
    
    @RequestMapping("/user/TeacherAgreeLaogai")
	public String TeacherAgreeLaogai(Integer ssVid) {//宿管同意劳改
		String state = "正在劳改";
		restTemplate.getForObject(REST_URL_PREFIX + "/SsViolation/UpdateViolationState/"+ssVid+"/"+state, int.class);
		return "redirect:TeacherToViolation";
	}
    
    @RequestMapping("/user/TeacherDisagreeLaogai")
	public String TeacherDisagreeLaogai(Integer ssVid) {//宿管拒绝劳改
		String state = "拒绝劳改";
		restTemplate.getForObject(REST_URL_PREFIX + "/SsViolation/UpdateViolationState/"+ssVid+"/"+state, int.class);
		return "redirect:TeacherToViolation";
	}
    
    @RequestMapping("/user/TeacherUpdateVstate")
	public String TeacherUpdateVstate(Integer ssVid) {//宿管修改劳改状态
		String state = "已劳改";
		restTemplate.getForObject(REST_URL_PREFIX + "/SsViolation/UpdateViolationState/"+ssVid+"/"+state, int.class);
		return "redirect:TeacherToViolation";
	}
    
    @SuppressWarnings("unchecked")
    @RequestMapping("/user/select")
	public String select(Model m,String s) {//查找
		List<SsViolation> list = restTemplate.postForObject(REST_URL_PREFIX + "/SsViolation/FindViolation", s, List.class);
		m.addAttribute("violation",list);
		return URL+"teacher_violation";
	}
    
    @RequestMapping("/user/toAddViolation")
	public String toAddViolation() {//跳转增加违规界面
		return URL+"violationInsert";
	}
    
    @RequestMapping("/user/ViolationInsertCommit")
	public String ViolationInsertCommit(String ssUname,String ssVthing,String ssVremark) {//提交违规
		SsUser user = restTemplate.postForObject(REST_URL_PREFIX + "/SsViolation/FindUserByUname", ssUname, SsUser.class);
		Integer did = user.getSsDid();
		Integer uid = user.getSsUid();
		SsViolation ssViolation = new SsViolation();
		ssViolation.setSsUid(uid);
		ssViolation.setSsDid(did);
		ssViolation.setSsVthing(ssVthing);
		ssViolation.setSsVremark(ssVremark);
		ssViolation.setSsVdate(new Date());
		if(ssVthing.equals("违规电器")) {
			ssViolation.setSsVstate("未劳改");
		}else {
			ssViolation.setSsVstate("未注销");
		}
		restTemplate.postForObject(REST_URL_PREFIX + "/SsViolation/AddViolation", ssViolation, int.class);
		return "redirect:TeacherToViolation";
	}
}
