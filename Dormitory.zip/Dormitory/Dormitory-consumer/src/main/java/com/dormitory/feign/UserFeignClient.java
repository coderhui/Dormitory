package com.dormitory.feign;

import com.dormitory.handler.UserFeignClientHandler;
import com.dormitory.pojo.SsUser;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient(value = "provider",fallback = UserFeignClient.class)
public interface UserFeignClient {

    @GetMapping("/user/findAll")
    public SsUser findAll();
}
