package com.dormitory.controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.ResourceUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.dormitory.pojo.SsRepair;
import com.dormitory.pojo.SsUser;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;

import coms.Commons;
@Controller
public class SsRepairController_Consumer {
    private static final String REST_URL_PREFIX = "http://localhost:8001";
    
    private static final String URL = "system/SsRepair/";
    
    @Autowired
    private RestTemplate restTemplate;
    
    @SuppressWarnings("unchecked")
    @RequestMapping("/user/findRepair")
	public String findRepair(Model m,HttpSession session) {//舍员进入维修呼叫界面
		SsUser user = (SsUser)session.getAttribute("user");
		int power = user.getSsPower();
		int ssDid = user.getSsDid();
		List<SsRepair> list = restTemplate.postForObject(REST_URL_PREFIX + "/SsRepair/FindRepairMesByDid",ssDid, List.class);
		m.addAttribute("repair",list);
		if(power == 1) {
			return URL+"student_repair";//舍员维修呼叫界面
		}else {
			return URL+"student_violation_shezhang";//舍长维修呼叫界面
		}	
	}
    
    @RequestMapping("/user/toRepairApply")
	public String toRepairApply() {//跳转维修申请界面
		return URL+"repair_apply";
	}
    
    @RequestMapping("/user/repairCommit")
	public String repairCommit(String ssRnr,String itemsPic,HttpSession session) {//维修申请提交
		SsUser user = (SsUser)session.getAttribute("user");
		int ssDid = user.getSsDid();
		SsRepair ssRepair = new SsRepair();
		ssRepair.setSsRnr(ssRnr);
		ssRepair.setSsDid(ssDid);
		ssRepair.setSsRimage(itemsPic);
		ssRepair.setSsRdate(new Date());
		ssRepair.setSsRstate("受理中");
		restTemplate.postForObject(REST_URL_PREFIX + "/SsRepair/AddRepair", ssRepair, boolean.class);
		return "redirect:findRepair";
	}
    
    @SuppressWarnings("unchecked")
    @RequestMapping("/user/TeacherToRepair")
    public String TeacherToRepair(Model m) {
    	List<SsRepair> list = restTemplate.getForObject(REST_URL_PREFIX + "/SsRepair/FindAllRepair", List.class);
    	m.addAttribute("repair",list);
    	return URL+"teacher_repair1";
    }
    
    @SuppressWarnings("unchecked")
    @RequestMapping("/user/TeacherRepair")
	public String teacherRepair(Model m) {//宿管点主界面进入维修查看
		List<SsRepair> list = restTemplate.getForObject(REST_URL_PREFIX + "/SsRepair/FindRepairMesByState", List.class);
		m.addAttribute("repair",list);
		return URL+"teacher_repair";
	}
    
    @RequestMapping("/user/TeacherAgreeRepair")
	public String TeacherAgreeRepair(int ssRid) {//宿管同意维修
    	String ssRstate = "同意维修";
    	restTemplate.getForObject(REST_URL_PREFIX + "/SsRepair/UpdateRepairState/"+ssRid+"/"+ssRstate, boolean.class);
		return "redirect:TeacherToRepair";
	}
    
    @RequestMapping("/user/TeacherDisagreeRepair")
	public String TeacherDisagreeRepair(int ssRid) {//宿管拒绝维修
		String ssRstate = "拒绝维修";
		restTemplate.getForObject(REST_URL_PREFIX + "/SsRepair/UpdateRepairState/"+ssRid+"/"+ssRstate, boolean.class);
		return "redirect:TeacherToRepair";
	}
    
    
	/* 
	 * 
	 * 图片跨服务器上传 
	 * 
	 * */
    @RequestMapping("/uploadPic")
    @ResponseBody
	public String uploadPic(@RequestParam("imgSize1File") MultipartFile file,HttpServletRequest req) throws IOException {
    	
    	byte[] bytes = file.getBytes(); //将图片转换为二进制
    	String newFileName="";
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
		newFileName = sdf.format(new Date());
		Random r = new Random();
		for(int i =0 ;i<3;i++){
			newFileName=newFileName+r.nextInt(10);
		}
    	//截取文件后缀名
    	String fileSuffix = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf("."));
    	//创建jesy服务器，进行跨服务器上传
		Client client = Client.create();
		//把文件关联到远程服务器
		WebResource resource = client.resource(Commons.pic+"/upload/"+newFileName+fileSuffix);
		resource.put(String.class, bytes);
		String fullPath = Commons.pic + "/upload/" + newFileName + fileSuffix;
		String relativePath = "/upload/" + newFileName + fileSuffix;
		System.out.println("绝对路径:"+fullPath);
		System.out.println("相对路径:"+relativePath);
		return "{\"fullPath\":\""+fullPath+"\",\"relativePath\":\""+relativePath+"\"}";
    }  
    
    
	/* 
	 * 图片上传到服务器
	 * 
	 *  */
    
    @RequestMapping("/uploadPic_local")
    @ResponseBody
    public String uploadPic_local(@RequestParam("imgSize1File") MultipartFile file,HttpServletRequest req) throws FileNotFoundException {
    	//得到文件上传路径
    	String path = ResourceUtils.getURL("classpath:").getPath().replace("%20", " ").replace('/', '\\')+"static\\upload";
    	String realPath = req.getServletContext().getRealPath("/");
    	System.out.println("path:"+path);
    	System.out.println("realPath:"+realPath);
    	String newFileName="";
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
		newFileName = sdf.format(new Date());
		Random r = new Random();
		for(int i =0 ;i<3;i++){
			newFileName=newFileName+r.nextInt(10);
		}
		//截取文件后缀名
    	String fileSuffix = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf("."));
    	// 得到文件上传的路径
    	// 如果此路径不存在，则创建
    	File dir =new File(path);
    	if(!dir.exists()){
    		dir.mkdirs();
    	}
    	File f = new File(dir + "/" + newFileName + fileSuffix);
    	try {
			file.transferTo(f);
		} catch (IllegalStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	String fullPath = path;
    	String relativePath = "/static/upload/" + newFileName + fileSuffix;
    	System.out.println("fullPath:"+fullPath+"    relativePath:"+relativePath);
    	return "{\"fullPath\":\""+fullPath+"\",\"relativePath\":\""+relativePath+"\"}";
    }
}
