package com.dormitory.controller;

import java.util.List;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;
import com.dormitory.pojo.SsUser;
import com.dormitory.pojo.SsWaterandelectricity;

@Controller
public class SsWaterandelectricityController_Consumer {
    private static final String REST_URL_PREFIX = "http://localhost:8001";
    
    @Autowired
    private RestTemplate restTemplate;
    
    @SuppressWarnings("unchecked")
	@RequestMapping("/user/welistteacher")//全查之宿舍升序-→老师
	public String weselect(Model m) {
		List<SsWaterandelectricity> wes = restTemplate.getForObject(REST_URL_PREFIX + "/SsWaterandelectricity/selWEandDorm", List.class);
		m.addAttribute("wes", wes);
		return "system/SsWaterandelectricity/WEList_teacher1";
	}
	
    @SuppressWarnings("unchecked")
	@RequestMapping("/user/weliststudent")//ssDid查-→学生
	public String weselectstudent(Model m,HttpSession session) {
		SsUser user = (SsUser)session.getAttribute("user");
		int power = user.getSsPower();
		List<SsWaterandelectricity> wes = restTemplate.postForObject(REST_URL_PREFIX + "/SsWaterandelectricity/selWEandDormandUserByssDid", user.getSsDid(), List.class);
		m.addAttribute("wes", wes);
		if(power == 1) {
			return "system/SsWaterandelectricity/WEList_sheyuan";//舍员
		}else {
			return "system/SsWaterandelectricity/WEList_shezhang";//舍长
		}	
	}
    
    @SuppressWarnings("unchecked")
	@RequestMapping("/user/weselect")//搜索框ssDname、ssWestate
	public String weselect(Model m,String c)  {
		List<SsWaterandelectricity> wes = restTemplate.postForObject(REST_URL_PREFIX + "/SsWaterandelectricity/selWEandUserandDormByssDnameandssWestate", c, List.class);
		m.addAttribute("wes", wes);
		return "system/SsWaterandelectricity/WEList_teacher";
	}
	
	@RequestMapping("/user/wecjteacher")//催交
	public String wecjteacher(int ssWeid) {
		String ssWestate = "正在催交";
		restTemplate.getForObject(REST_URL_PREFIX + "/SsWaterandelectricity/UpdateWEState/"+ssWeid+"/"+ssWestate, int.class);
		return "redirect:welistteacher";
	}
	
	@RequestMapping("/user/wecjstudentzhifu")//舍长点立马支付
	public String wecjstudentzhifu(int ssWeid) {
		String ssWestate = "正在支付";
		restTemplate.getForObject(REST_URL_PREFIX + "/SsWaterandelectricity/UpdateWEState/"+ssWeid+"/"+ssWestate, int.class);
		return "redirect:weliststudent";
	}
	
	@RequestMapping("/user/wecjstudentshaohou")//舍长点稍后支付
	public String wecjstudentshaohou(int ssWeid) {
		String ssWestate = "未支付";
		restTemplate.getForObject(REST_URL_PREFIX + "/SsWaterandelectricity/UpdateWEState/"+ssWeid+"/"+ssWestate, int.class);
		return "redirect:weliststudent";
	}
	
	@RequestMapping("/user/weupdatesave")//改
	public String weupdatesave(int ssWeid,int ssEnum,int ssWnum,Double ssMoney) {
		System.out.println("222222");
		restTemplate.getForObject(REST_URL_PREFIX + "/SsWaterandelectricity/UpdateWEwenum/"+ssWeid+"/"+ssEnum+"/"+ssWnum+"/"+ssMoney,int.class);
		System.out.println("3333333");
		return "redirect:welistteacher";
	}
	
	@RequestMapping("/user/weupdate")//ssWeid查,进入改
	public String weupdatesave(Model m , int ssWeid) {
		SsWaterandelectricity updatewes = restTemplate.postForObject(REST_URL_PREFIX + "/SsWaterandelectricity/selWEandDormByssWeid",ssWeid, SsWaterandelectricity.class);
		m.addAttribute("updatewes", updatewes);
		System.out.println("11111");
		return "system/SsWaterandelectricity/WEEdit";
	}


}
