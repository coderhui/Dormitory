function check() {
		var a = $("#to").val();
		var uid = $("#uid").val();
		var json = JSON.stringify({"ssUid":uid,"to":a});
		$.ajax({
			type : 'POST',
			url : '/subscribe',
			contentType : 'application/json;charset=UTF-8',
			dataType : 'json',
			data : json,
			success : function(data) {
				var b = eval(data);
				if(b.flag == 0){
					alert('您的余额不足,无法购买!')
				}else{
					$("#ssMoney").val(b.money);
					alert('购买成功!');
				}
			}
		})
	}