function email(){
		var a = document.getElementById("eml");
		var eml = a.value;
		var json = JSON.stringify({"Eml":eml});
  		$.ajax({
  			type:'POST',
  			url:'/send',
  			contentType: 'application/json;charset=UTF-8',
  			dataType: 'json',
  			data:json,
  			success: function(data){
  				var b = eval(data);
  				$("#e_code").val(b.code);
  			}
  		})
	}
	
	function username_check(){
		var ssUname = $("#ssUname").val();
		var json = JSON.stringify({"ssUname":ssUname});
		$.ajax({
  			type:'POST',
  			url:'/register_username_check',
  			contentType: 'application/json;charset=UTF-8',
  			dataType: 'json',
  			data:json,
  			success: function(data){
  				var b = eval(data);
  				if(b.flag == 1){
  					alert('用户名已存在!');
  				}
  				if(b.flag == 1){
  					$("#un").val('1');
  				}else{
  					$("#un").val('0');
  				}
  			}
  		})
	}
	
	function register_username_check(){
		var ssUname = $("#ssUname").val();
		var json = JSON.stringify({"ssUname":ssUname});
		$.ajax({
  			type:'POST',
  			url:'/register_username_check',
  			contentType: 'application/json;charset=UTF-8',
  			dataType: 'json',
  			data:json,
  			async:false,
  			success: function(data){
  				var b = eval(data);
  				if(b.flag == 1){
  					$("#un").val('1');
  				}else{
  					$("#un").val('0');
  				}
  			}
  		})
	}
	
	function check(){
		var e_code = $("#e_code").val();
		var email_code = $("#email_code").val();
		var pw_check = $("#pw").val();
		var un_check = $("#un").val();
		if(un_check == 1){
			alert('用户名已存在!');
			event.preventDefault();
		}else{
			if(pw_check == 1){
				if(email_code == ""){
					alert('请输入邮箱验证码');
					event.preventDefault();
				}else{
					if(e_code == email_code){
						alert('注册成功');
						$("#register_submit").submit();
					}else{
						alert('验证码不对!');
						event.preventDefault();
					}
				}
			}else{
				alert('两次密码不一致');
				event.preventDefault();
			}
		}	
	}
	
	function password_check(){
		var pw1 = $("#ssPassword").val();
		var pw2 =$("#ssPassword2").val();
		if(pw1 == ""){
			alert('密码不能为空!');
		}
		if(pw2 == ""){
			alert('请再次输入密码!');
		}
		if(pw1 == pw2){
			$("#pw").val('1');
		}else{
			$("#pw").val('0');
		}
	}
	
	//发送验证码函数
	function sendsms(e){
	    /*发送验证码功能*/
		email();
	    countdown(e);                                   //若发送验证码成功，则调用倒计时函数
	}
	//倒计时函数
	var time = 60;
	function countdown(e){
	    if (time == 0) {
	        //e.setAttribute('disabled',false);         对没有disbaled属性的span标签，此方法无效
	        e.setAttribute("onclick","sendsms(this)");
	        $("#validate_span").html("获取验证码");
	        time = 60;
	    }else{
	        //e.attr('disabled',true);                  对没有disbaled属性的span标签，此方法也无效
	        //e.setAttribute("onclick", '');            这样写也可以
	        e.removeAttribute("onclick");
	        $("#validate_span").html("重新发送(" + time + ")");
	        time--;
	        setTimeout(function() {
	            countdown(e)
	        },1000)
	    }
	}
	