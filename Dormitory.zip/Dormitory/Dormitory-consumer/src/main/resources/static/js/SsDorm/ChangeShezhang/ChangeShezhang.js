function check(){
	var ssDid = $("#ssDid").val();
	var ssUname = $("#ssUname").val();
	var json = JSON.stringify({"ssUname":ssUname,"ssDid":ssDid});
		$.ajax({
			type:'POST',
			url:'/changeShezhangCheck',
			contentType: 'application/json;charset=UTF-8',
			dataType: 'json',
			data:json,
			success: function(data){
				var a = eval(data);
				var b = a.flag;
				if(b == 0){
					alert('您输入的人不在该宿舍的人员列表中!');
				}else{
					$.ajax({
						type:'POST',
						url:'/ChangeShezhangSave',
						contentType: 'application/json;charset=UTF-8',
						dataType: 'json',
						data:json,
						success: function(data){
							var c = eval(data);
							$("#shezhang").val(c.flag);
							$("#ssUname").val('');
						}
					})
				}			
			}
		})
}