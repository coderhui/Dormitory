function email(){
		var username = $("#ssUname").val();
		var email = $("#ssEmail").val();
		
		if(isEmpty(username)){
			alert('请输入用户名!');
		}else{
			if(isEmpty(email)){
				alert('请输入邮箱!');
			}else{
				var json = JSON.stringify({"ssUname":username,"ssEmail":email});
		  		$.ajax({
		  			type:'POST',
		  			url:'/sendEmail_findPw',
		  			contentType: 'application/json;charset=UTF-8',
		  			dataType: 'json',
		  			data:json,
		  			success: function(data){
		  				var b = eval(data);
		  				if(b.status == 0){
		  					alert('用户名不存在!');
		  				}
		  				if(b.status == 1){
		  					alert('您输入的邮箱不正确!')
		  				}
		  				if(b.status == 2){
		  					alert('密码已发送至您的邮箱!');
		  				}
		  			}
		  		})
			}
		}	
}

function isEmpty(v) {
    switch (typeof v) {
    case 'undefined':
        return true;
    case 'string':
        if (v.replace(/(^[ \t\n\r]*)|([ \t\n\r]*$)/g, '').length == 0) return true;
        break;
    case 'boolean':
        if (!v) return true;
        break;
    case 'number':
        if (0 === v || isNaN(v)) return true;
        break;
    case 'object':
        if (null === v || v.length === 0) return true;
        for (var i in v) {
            return false;
        }
        return true;
    }
    return false;
}