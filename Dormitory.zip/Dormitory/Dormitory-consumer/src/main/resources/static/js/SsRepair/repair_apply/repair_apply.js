function submitImgSize1Upload(){
	var imgFile = document.getElementById("imgSize1File").files[0];
	/*图片类型正则验证*/
	var imgStr = /\.(jpg|jpeg|png|bmp|BMP|JPG|PNG|JPEG)$/;
	if(!imgStr.test(imgFile.name)) {
		alert("文件不是图片类型");
		$("#check_type").val("0");
		return false;
	} else {
		$("#check_type").val("1");
		var option={
				type:'POST',
				url:'/uploadPic',
				dataType:'json',
				success: function(data){
					//把json格式的字符串转换成json对象
					var a = eval(data);
					//返回服务器图片路径，把图片路径设置给img标签
					$("#imgSize1ImgSrc").attr("src",a.fullPath);
					//数据库保存相对路径
					$("#imgSize1").val(a.relativePath);
				}
			};
		$("#repairForm").ajaxSubmit(option);	
	}	
}

function check_type(){
	var flag = $("#check_type").val();
	var n = $("#ssRnr").val();
	if(isEmpty(n)){
		alert('维修内容不能为空!');
		event.preventDefault();
	}else{
		if(flag == 0){
			alert('文件不是图片类型!');
			event.preventDefault();
		}
		if(flag == 1){
			$("#repair_submit").submit();
		}
		if(flag == 10){
			alert('请上传图片');
			event.preventDefault();
		}
	}
}

function isEmpty(v) {
    switch (typeof v) {
    case 'undefined':
        return true;
    case 'string':
        if (v.replace(/(^[ \t\n\r]*)|([ \t\n\r]*$)/g, '').length == 0) return true;
        break;
    case 'boolean':
        if (!v) return true;
        break;
    case 'number':
        if (0 === v || isNaN(v)) return true;
        break;
    case 'object':
        if (null === v || v.length === 0) return true;
        for (var i in v) {
            return false;
        }
        return true;
    }
    return false;
}