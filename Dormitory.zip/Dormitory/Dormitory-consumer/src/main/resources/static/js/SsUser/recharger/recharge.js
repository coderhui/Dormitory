function recharge_check(){
	var money = $("#ssMoney").val();
	if(money == ""){
		alert('充值金额不能为空!');
		event.preventDefault();
	}
}