function check(){
	var username = $("#username").val();
	var password = $("#password").val();
	
	if(isEmpty(username)){
		alert('用户名不能为空!');
		event.preventDefault();
	}else{
		if(isEmpty(password)){
			alert('密码不能为空!');
			event.preventDefault();
		}else{
			var json = JSON.stringify({"username":username,"password":password});
			$.ajax({
				type:'POST',
				url:'/check',
				contentType: 'application/json;charset=UTF-8',
				dataType: 'json',
				data:json,
				async:false,
				success: function(data){
					var a = eval(data);
					if(a.status != 0){
						if(a.status == 2){
							$("#dl").val('2');
							/*alert('密码错误!');
							event.preventDefault();*/
						}else{
							$("#dl").val('1');
							/*alert('登陆成功');*/
						}	
					}else{
						$("#dl").val('0');
						/*alert('用户名不存在!');
						event.preventDefault();*/
					}
				}
			})
			var i = $("#dl").val();
			var yz = $("#yz").val();
			if(yz == 1){
				if(i == 0){
					alert('用户名不存在!');
					event.preventDefault();
					location.reload();
				}else{
					if(i == 2){
						alert('密码错误!');
						event.preventDefault();
						location.reload();
					}else{
						$("#login_submit").submit();
					}
				}
			}else{
				alert('请将滑块划至右边!');
				event.preventDefault();
			}
		}	
	}
}

function isEmpty(v) {
    switch (typeof v) {
    case 'undefined':
        return true;
    case 'string':
        if (v.replace(/(^[ \t\n\r]*)|([ \t\n\r]*$)/g, '').length == 0) return true;
        break;
    case 'boolean':
        if (!v) return true;
        break;
    case 'number':
        if (0 === v || isNaN(v)) return true;
        break;
    case 'object':
        if (null === v || v.length === 0) return true;
        for (var i in v) {
            return false;
        }
        return true;
    }
    return false;
}

