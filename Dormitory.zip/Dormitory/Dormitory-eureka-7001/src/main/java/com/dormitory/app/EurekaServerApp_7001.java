package com.dormitory.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@SpringBootApplication
//接受其他微服务进来
@EnableEurekaServer
public class EurekaServerApp_7001 {
	public static void main(String[] args) {
		SpringApplication.run(EurekaServerApp_7001.class, args);
		System.out.println("7001OK");
	}
}
