package com.dormitory.dao;

import com.dormitory.pojo.SsViolation;
import com.dormitory.pojo.SsViolationExample;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface SsViolationDao {
    int countByExample(SsViolationExample example);

    int deleteByExample(SsViolationExample example);

    int deleteByPrimaryKey(Integer ssVid);

    int insert(SsViolation record);

    int insertSelective(SsViolation record);

    List<SsViolation> selectByExample(SsViolationExample example);

    SsViolation selectByPrimaryKey(Integer ssVid);

    int updateByExampleSelective(@Param("record") SsViolation record, @Param("example") SsViolationExample example);

    int updateByExample(@Param("record") SsViolation record, @Param("example") SsViolationExample example);

    int updateByPrimaryKeySelective(SsViolation record);

    int updateByPrimaryKey(SsViolation record);
    
    List<SsViolation> FindAllViolation();//查找所有违规记录
    
    List<SsViolation> FindViolationMesByUid(int ssUid);//根据uid查找违规记录
    
    List<SsViolation> FindViolation(String s);//查找违规
}