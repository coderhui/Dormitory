package com.dormitory.service;

import java.util.Date;
import java.util.List;
import com.dormitory.pojo.SsLeave;

public interface ISsLeaveService {
	
	List<SsLeave> selLeaveandUserandDormByssLwdateDESCandssDname();//全查之离返日期降序,宿舍升序-→老师

	SsLeave selLeaveandUserandDormByssLid(Integer ssLid);//ssLid查,进入改
	
	List<SsLeave> selLeaveandUserandDormByssUidandsslwdateDESC(Integer ssUid);//ssUid查,ssLwdate、ssLbdate降序-→学生
	
	List<SsLeave> selLeaveandUserandDormByssUnameandssDname(String b);//搜索框ssUname、ssDname查
	
    int UpdateLeave(Integer ssLid,Date ssLwdate,Date ssLbdate,String ssLstatus);//改
    
    int insertSelective(SsLeave record);//加

}
