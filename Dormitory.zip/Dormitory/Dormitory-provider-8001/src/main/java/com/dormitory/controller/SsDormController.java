package com.dormitory.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dormitory.pojo.SsUser;
import com.dormitory.service.ISsDormService;
import com.dormitory.service.ISsUserService;

@RestController
@RequestMapping("/SsDorm")
public class SsDormController {
	
	@Autowired
	private ISsDormService dormService;
	@Autowired
	private ISsUserService userService;
	
	
	@RequestMapping("/FindAllUserAndDormMes")
	public List<SsUser> FindAllUserAndDormMes(){//查找所有用户信息
		return userService.FindAllUserAndDormMes();
	}
	
	@RequestMapping("/FindUserAndDormMesByDid")
	public List<SsUser> FindUserAndDormMesByDid(@RequestBody int ssDid){//按照宿舍id查找用户
		return userService.FindUserAndDormMesByDid(ssDid);
	}
	
	@RequestMapping("/FindUserByUname")
	public SsUser FindUserByUname(@RequestBody String ssUname) {//按照用户名查找用户
		return userService.FindUserByUname(ssUname);
	}
	
	@GetMapping("/UpdateShezhang/{ssUname}/{ssDid}")
	public boolean UpdateShezhang(@PathVariable String ssUname,@PathVariable int ssDid) {
		return userService.UpdateShezhang(ssUname, ssDid);
	}
}
