package com.dormitory.dao;

import com.dormitory.pojo.SsLeave;
import com.dormitory.pojo.SsLeaveExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface SsLeaveDao {
    int countByExample(SsLeaveExample example);

    int deleteByExample(SsLeaveExample example);

    int deleteByPrimaryKey(Integer ssLid);

    int insert(SsLeave record);

    int insertSelective(SsLeave record);

    List<SsLeave> selectByExample(SsLeaveExample example);

    SsLeave selectByPrimaryKey(Integer ssLid);

    int updateByExampleSelective(@Param("record") SsLeave record, @Param("example") SsLeaveExample example);

    int updateByExample(@Param("record") SsLeave record, @Param("example") SsLeaveExample example);

    int updateByPrimaryKeySelective(SsLeave record);

    int updateByPrimaryKey(SsLeave record);
    
    List<SsLeave> selLeaveandUserandDormByssLwdateDESCandssDname();//全查之离返日期降序,宿舍升序
    
    SsLeave selLeaveandUserandDormByssLid(Integer ssLid);//ssLid查
    
    List<SsLeave> selLeaveandUserandDormByssUidandsslwdateDESC(Integer ssUid);//ssUid查,ss_Lwdate、ss_lbdate降序
    
    List<SsLeave> selLeaveandUserandDormByssUnameandssDname(String b);//搜索框ssUname、ssDname查
}