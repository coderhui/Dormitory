package com.dormitory.service.impl;

import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.dormitory.dao.SsLeaveDao;
import com.dormitory.pojo.SsLeave;
import com.dormitory.service.ISsLeaveService;

@Service
public class SsLeaveServiceImpl implements ISsLeaveService {
	@Autowired
	private SsLeaveDao leavedao;
		
	@Override//全查之离返日期降序,宿舍升序-→老师
	public List<SsLeave> selLeaveandUserandDormByssLwdateDESCandssDname() {
		return leavedao.selLeaveandUserandDormByssLwdateDESCandssDname();
	}
	@Override//ssLid查,进入改
	public SsLeave selLeaveandUserandDormByssLid(Integer ssLid) {
		return leavedao.selLeaveandUserandDormByssLid(ssLid);
	}
	@Override//ssUid查,ssLwdate、ssLbdate降序-→学生
	public List<SsLeave> selLeaveandUserandDormByssUidandsslwdateDESC(Integer ssUid) {
		return leavedao.selLeaveandUserandDormByssUidandsslwdateDESC(ssUid);
	}
	@Override//搜索框ssUname、ssDname查
	public List<SsLeave> selLeaveandUserandDormByssUnameandssDname(String b) {
		return leavedao.selLeaveandUserandDormByssUnameandssDname(b);
	}
	@Override//改
	public int UpdateLeave(Integer ssLid, Date ssLwdate, Date ssLbdate, String ssLstatus) {
		SsLeave ssleave = new SsLeave();
		ssleave.setSsLid(ssLid);
		ssleave.setSsLwdate(ssLwdate);
		ssleave.setSsLbdate(ssLbdate);
		ssleave.setSsLstatus(ssLstatus);
		return leavedao.updateByPrimaryKeySelective(ssleave);
	}
	@Override//加
	public int insertSelective(SsLeave record) {
		return leavedao.insertSelective(record);
	}

}
