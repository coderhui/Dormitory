package com.dormitory.service;

import java.util.List;

import com.dormitory.pojo.SsDorm;

public interface ISsDormService {
	List<SsDorm> FindAllDorm();//查找所有宿舍
	
	//按ssDname查ssDid
	List<SsDorm> selectByssDname(String ssDname);
	
	List<SsDorm> selDormandUserall();//全部宿舍
}
