package com.dormitory.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dormitory.dao.SsUserDao;
import com.dormitory.pojo.SsUser;
import com.dormitory.pojo.SsUserExample;
import com.dormitory.pojo.SsUserExample.Criteria;
import com.dormitory.service.ISsUserService;

@Service
public class SsUserServiceImpl implements ISsUserService{
	@Autowired
	private SsUserDao userDao;

	public SsUser FindUserByNameAndPw(String username, String password) {//按用户名密码查找
		// TODO Auto-generated method stub
		SsUserExample example = new SsUserExample();
		Criteria criteria = example.createCriteria();
		criteria.andSsUnameEqualTo(username);
		criteria.andSsPasswordEqualTo(password);
		List<SsUser> list = userDao.selectByExample(example);
		if(list.isEmpty()) {
			SsUser user = new SsUser();
			user.setSsPower(0);
			return user;
		}else {
			return list.get(0);
		}
	}

	public int AddUser(SsUser user) {//插入用户
		// TODO Auto-generated method stub
		return userDao.insertSelective(user);
	}

	public int UpdateUser(SsUser user) {//修改用户信息
		// TODO Auto-generated method stub
		return userDao.updateByPrimaryKeySelective(user);
	}

	public boolean CheckUsername(String username) {//验证用户名
		// TODO Auto-generated method stub
		SsUserExample example = new SsUserExample();
		Criteria criteria = example.createCriteria();
		criteria.andSsUnameEqualTo(username);
		List<SsUser> list = userDao.selectByExample(example);
		if(list.size() != 0) {
			return true;
		}
		return false;
	}

	public boolean CheckPassword(String username,String password) {//验证密码
		// TODO Auto-generated method stub
		SsUserExample example = new SsUserExample();
		Criteria criteria = example.createCriteria();
		criteria.andSsUnameEqualTo(username);
		List<SsUser> list = userDao.selectByExample(example);
		if(list.size() != 0) {
			SsUser user = list.get(0);
			if(password.equals(user.getSsPassword())) {//密码正确
				return true;
			}
		}	
		return false;
	}

	@Override
	public SsUser FindUserAllMes(int uid) {//查找用户信息
		// TODO Auto-generated method stub
		return userDao.findUserAndDorm(uid);
	}

	@Override
	public boolean CheckEmail(String username, String email) {//验证邮箱
		// TODO Auto-generated method stub
		SsUserExample example = new SsUserExample();
		Criteria criteria = example.createCriteria();
		criteria.andSsUnameEqualTo(username);
		List<SsUser> list = userDao.selectByExample(example);
		if(list.size() != 0) {
			SsUser user = list.get(0);
			if(email.equals(user.getSsEmail())) {//判断邮箱是否正确
				return true;
			}
		}
		return false;
	}

	@Override
	public SsUser FindUserByNameAndEmail(String username, String email) {//按照邮箱和用户名查找密码
		// TODO Auto-generated method stub
		SsUserExample example = new SsUserExample();
		Criteria criteria = example.createCriteria();
		criteria.andSsUnameEqualTo(username);
		criteria.andSsEmailEqualTo(email);
		List<SsUser> list = userDao.selectByExample(example);
		if(list.size() != 0) {
			return list.get(0);
		}
		return null;
	}

	@Override
	public List<SsUser> FindAllUserAndDormMes() {//查找所有用户信息(包括宿舍信息)
		// TODO Auto-generated method stub
		List<SsUser> list = userDao.findUserAndDormMes();
		List<SsUser> list2 = new ArrayList<SsUser>();
		int i = -1;
		boolean flag = true;	
		for (SsUser ssUser : list) {
			String shezhang = "未指定!";
			if(ssUser.getSsDid() != i && ssUser.getSsPower() !=3) {//判断该宿舍是否已经整合
				if(ssUser.getSsPower() == 2) {//判断第一个人是否为舍长
					shezhang = ssUser.getSsUname();
					flag = false;
				}
				for (SsUser ssUser2 : list) {
					if(ssUser2.getSsDid() == ssUser.getSsDid() && ssUser2.getSsUid() != ssUser.getSsUid()) {
						if(flag) {
							if(ssUser2.getSsPower() == 2) {//判断后面的人是否为舍长
								shezhang = ssUser2.getSsUname();
							}
						}	
						ssUser.setSsUname(ssUser.getSsUname()+","+ssUser2.getSsUname());
						
						i = ssUser2.getSsDid();
					}
				}
				ssUser.setSsEmail(shezhang);//用于存储舍长是谁
				list2.add(ssUser);
			}	
		}
		return list2;
	}

	@Override
	public List<SsUser> FindAllUserMes() {//查找所有用户
		// TODO Auto-generated method stub
		return userDao.findUserAndDormMes();
	}
	
	@Override//按ssUname查ssUid
	public List<SsUser> selectByssUname(String ssUname) {
		SsUserExample example = new SsUserExample();
		Criteria criteria = example.createCriteria();
		criteria.andSsUnameEqualTo(ssUname);
		return userDao.selectByExample(example);
	}

	@Override
	public List<SsUser> FindUserAndDormMesByDid(int ssDid) {//根据did查找宿舍人员信息
		// TODO Auto-generated method stub
		List<SsUser> list = userDao.findUserAndDormMesByDid(ssDid);
		List<SsUser> list2 = new ArrayList<SsUser>();
		int i = -1;
		boolean flag = true;
		for (SsUser ssUser : list) {
			String shezhang = "未指定!";
			if(ssUser.getSsDid() != i && ssUser.getSsPower() !=3) {//判断该宿舍是否已经整合
				if(ssUser.getSsPower() == 2) {//判断第一个人是否为舍长
					shezhang = ssUser.getSsUname();
					flag = false;
				}
				for (SsUser ssUser2 : list) {
					if(ssUser2.getSsDid() == ssUser.getSsDid() && ssUser2.getSsUid() != ssUser.getSsUid()) {
						if(flag) {
							if(ssUser2.getSsPower() == 2) {
								shezhang = ssUser2.getSsUname();
							}
						}	
						ssUser.setSsUname(ssUser.getSsUname()+","+ssUser2.getSsUname());
						
						i = ssUser2.getSsDid();
					}
				}
				ssUser.setSsEmail(shezhang);//用于存储舍长是谁
				list2.add(ssUser);
			}
		}
		return list2;
	}

	@Override
	public SsUser FindUserByUname(String ssUname) {//按用户名查找用户
		// TODO Auto-generated method stub
		SsUserExample example = new SsUserExample();
		Criteria criteria = example.createCriteria();
		criteria.andSsUnameEqualTo(ssUname);
		List<SsUser> list = userDao.selectByExample(example);
		if(list.size() > 0) {
			return list.get(0);
		}
		return new SsUser();
	}

	@Override
	public boolean UpdateShezhang(String ssUname,int ssDid) {//修改宿舍舍长
		// TODO Auto-generated method stub
		SsUserExample example1 = new SsUserExample();
		Criteria criteria1 = example1.createCriteria();
		criteria1.andSsUnameEqualTo(ssUname);
		List<SsUser> list2 = userDao.selectByExample(example1);
		SsUser user = list2.get(0);
		SsUserExample example2 = new SsUserExample();
		Criteria criteria2 = example2.createCriteria();
		criteria2.andSsDidEqualTo(ssDid);
		List<SsUser> list = userDao.selectByExample(example2);
		for (SsUser ssUser : list) {
			if(ssUser.getSsPower() == 2) {
				ssUser.setSsPower(1);//将原来舍长权限改为1
				userDao.updateByPrimaryKeySelective(ssUser);
			}
		}
		user.setSsPower(2);
		userDao.updateByPrimaryKeySelective(user);//将新舍长权限改为2
		return true;
	}
}
