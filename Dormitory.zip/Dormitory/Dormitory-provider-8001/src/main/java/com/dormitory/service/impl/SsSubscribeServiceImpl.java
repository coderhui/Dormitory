package com.dormitory.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dormitory.dao.SsSubscribeDao;
import com.dormitory.dao.SsUserDao;
import com.dormitory.pojo.SsSubscribe;
import com.dormitory.pojo.SsUser;
import com.dormitory.service.ISsSubscribeService;

import coms.Commons;

@Service
public class SsSubscribeServiceImpl implements ISsSubscribeService{
	
	@Autowired
	private SsUserDao userDao;
	
	@Autowired
	private SsSubscribeDao Dao;

	@Override
	@Transactional
	public void BuyWater(int ssUid) {//买水
		// TODO Auto-generated method stub
		SsUser user = userDao.selectByPrimaryKey(ssUid);
		user.setSsMoney(user.getSsMoney() - Commons.water_price);
		userDao.updateByPrimaryKeySelective(user);
		SsUser user2 = userDao.selectByPrimaryKey(Commons.water_uid);
		user2.setSsMoney(user2.getSsMoney() + Commons.water_price);
		userDao.updateByPrimaryKeySelective(user2);
		SsSubscribe s = new SsSubscribe();
		s.setSsUid(ssUid);
		s.setSsSstatus("已付款");
		s.setSsScost(Commons.water_price);
		s.setSsSnr("饮用水一桶");
		s.setSsSto("自取");
		Dao.insertSelective(s);
	}

	@Override
	@Transactional 
	public void BuyWaterAndTo(int ssUid) {//买水并送上门
		// TODO Auto-generated method stub
		SsUser user = userDao.selectByPrimaryKey(ssUid);
		user.setSsMoney(user.getSsMoney() - Commons.water_price - Commons.water_to_price);
		userDao.updateByPrimaryKeySelective(user);
		SsUser user2 = userDao.selectByPrimaryKey(Commons.water_uid);
		user2.setSsMoney(user2.getSsMoney() + Commons.water_price + Commons.water_to_price);
		userDao.updateByPrimaryKeySelective(user2);
		
		SsUser user3 = userDao.findUserAndDorm(ssUid);
		SsSubscribe s = new SsSubscribe();
		s.setSsUid(ssUid);
		s.setSsSstatus("配送中");
		s.setSsScost(Commons.water_price + Commons.water_to_price);
		s.setSsSnr("饮用水一桶+配送");
		s.setSsSto(user3.getSsDorm().getSsDname());
		Dao.insertSelective(s);
	}

	@Override
	public List<SsSubscribe> FindAllSubscirbe() {//查找所有买水记录
		// TODO Auto-generated method stub
		return Dao.FindAllSubscribe();
	}

	@Override
	public int UpdateSsStatus(int ssSid, String status) {//修改买水状态
		// TODO Auto-generated method stub
		SsSubscribe s = new SsSubscribe();
		s.setSsSid(ssSid);
		s.setSsSstatus(status);
		return Dao.updateByPrimaryKeySelective(s);
	}

}
