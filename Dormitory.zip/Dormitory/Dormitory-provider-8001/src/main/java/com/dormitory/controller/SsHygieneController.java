package com.dormitory.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.dormitory.pojo.SsHygiene;
import com.dormitory.service.ISsHygieneService;

@RestController
public class SsHygieneController {
	@Autowired 
	private ISsHygieneService hygieneservice;
		
	@RequestMapping("/SsHygiene/selHygieneandDormandUserByssHdateDESCandssDname")//全查之时间降序,宿舍升序--→老师
	public List<SsHygiene> selHygieneandDormandUserByssHdateDESCandssDname() {
		return hygieneservice.selHygieneandDormandUserByssHdateDESCandssDname();
	}
	
	@RequestMapping("/SsHygiene/selHygieneandDormandUserByssDidandssHdateDESC")//ssDid查,日期降序-→学生
	public List<SsHygiene> selHygieneandDormandUserByssDidandssHdateDESC(@RequestBody int ssDid) {
		return hygieneservice.selHygieneandDormandUserByssDidandssHdateDESC(ssDid);
	
	}
	
	@RequestMapping("/SsHygiene/selHygieneandDormandUserByssDname")//搜索框ssDname查
	public List<SsHygiene> selHygieneandDormandUserByssDname(@RequestBody String s) {
		return hygieneservice.selHygieneandDormandUserByssDname(s);
	}
	
	@RequestMapping("/SsHygiene/deletehygiene")//删
	public int deletehygiene(@RequestBody int ssHid) {
		return hygieneservice.deletehygiene(ssHid);
	}
	
	//(int ssHid,String ssDname,int ssBed,int ssCh,int ssYt,int ssWc,int ssWs,int ssHnum,Date ssHdate)
	@RequestMapping("/SsHygiene/updateByssHid/{ssDname}")//改
	public int updateByssHid(@RequestBody SsHygiene record,@PathVariable("ssDname") String ssDname) {
		return hygieneservice.updateByssHid(record, ssDname);
	}
	
	@RequestMapping("/SsHygiene/selHygieneandDormByssHid")//ssHid查,进入改
	public SsHygiene selHygieneandDormByssHid(@RequestBody int ssHid) {
		return hygieneservice.selHygieneandDormByssHid(ssHid);
	}
	
	@RequestMapping("/SsHygiene/InsertHy")//加
	public boolean InsertHy() {
		System.out.println("2341242132");
		hygieneservice.InsertHy();
		return true;
	}
	
}
