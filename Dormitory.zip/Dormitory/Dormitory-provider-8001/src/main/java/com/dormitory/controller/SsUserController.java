package com.dormitory.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dormitory.emailservice.IEmailService;
import com.dormitory.pojo.SsDorm;
import com.dormitory.pojo.SsRepair;
import com.dormitory.pojo.SsUser;
import com.dormitory.pojo.SsViolation;
import com.dormitory.service.ISsDormService;
import com.dormitory.service.ISsRepairService;
import com.dormitory.service.ISsUserService;
import com.dormitory.service.ISsViolationService;
import com.dormitory.util.achieveCode;

@RestController
@RequestMapping("/SsUser")
public class SsUserController {
	
	@Autowired
	private ISsUserService userService;
	@Autowired
	private IEmailService emailService;
	@Autowired
	private ISsDormService dormService;
	@Autowired
	private ISsRepairService repairService;
	@Autowired
	private ISsViolationService violationService;
		
	@PostMapping("/usernameCheck")
	public boolean usernameCheck(@RequestBody String username) {//判断用户是否存在
		return userService.CheckUsername(username);
	}
	
	@PostMapping("/passwordCheck")
	public boolean passwordCheck(@RequestBody SsUser user) {//判断密码是否正确
		return userService.CheckPassword(user.getSsUname(), user.getSsPassword());
	}
	
	@GetMapping("/FindUserByNameAndPw/{username}/{password}")
	public SsUser FindUserByNameAndPw(@PathVariable String username,@PathVariable String password) {//按用户名和密码查找
		return userService.FindUserByNameAndPw(username, password);
	}
	
	@RequestMapping("/FindAllDorm")
	public List<SsDorm> FindAllDorm(){//查找所有宿舍信息
		return dormService.FindAllDorm();
	}
	
	@RequestMapping("/FindAllUserMes")
	public List<SsUser> FindAllUserMes(){//查找所有用户信息
		return userService.FindAllUserMes();
	}
	
	@RequestMapping("/FindAllRepairMes")
	public List<SsRepair> FindAllRepairMes(){//查找所有维修信息
		return repairService.FindAllRepairMes();
	}
	
	@RequestMapping("/FindAllViolationMes")
	public List<SsViolation> FindAllViolationMes(){//查找所有违规信息
		return violationService.FindAllViolationMes();
	}
	
	@RequestMapping("/sendSimpleEmail")
	public String sendSimpleEmail(@RequestBody SsUser user) {//发送邮箱验证码
		String code = achieveCode.Code();//生成邮箱验证码
		String email = user.getSsEmail();
		//System.out.println("邮箱:"+email);
		emailService.sendSimpleEmail(email, "邮箱验证码", "尊敬的用户! 您的邮箱验证码为:"+code);//发送邮箱验证码
		return code;
	}
	
	@RequestMapping("/addUser")
	public boolean AddUser(@RequestBody SsUser user) {//添加用户
		userService.AddUser(user);
		return true;
	}
	
	@RequestMapping("/checkEmail")
	public boolean CheckEmail(@RequestBody SsUser user) {//判断邮箱是否正确
		return userService.CheckEmail(user.getSsUname(), user.getSsEmail());
	}
	
	@RequestMapping("/sendPassword")
	public boolean sendPassword(@RequestBody SsUser user) {//发送密码到用户邮箱
		SsUser user2 = userService.FindUserByNameAndEmail(user.getSsUname(), user.getSsEmail());
		emailService.sendSimpleEmail(user.getSsEmail(), "找回密码", "尊敬的用户! 您的密码为:"+user2.getSsPassword());//发送密码到用户邮箱
		return true;
	}
	
	@RequestMapping("/recharge")
	public boolean recharge(@RequestBody SsUser user) {//充值
		userService.UpdateUser(user);
		return true;
	}
	
	@RequestMapping("/FindUserAllMes")
	public SsUser FindUserAllMes(@RequestBody int ssUid) {
		return userService.FindUserAllMes(ssUid);
	}
}