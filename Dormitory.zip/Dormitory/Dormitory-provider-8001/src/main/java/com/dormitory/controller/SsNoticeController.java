package com.dormitory.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.dormitory.pojo.SsNotice;
import com.dormitory.service.ISsNoticeService;

@RestController
public class SsNoticeController {
	@Autowired 
	private ISsNoticeService noticeservice;
	
	@RequestMapping("/SsNotice/selectByssNdateDESC")//全查之时间降序
	public List<SsNotice> selectByssNdateDESC() {
			return noticeservice.selectByssNdateDESC();
	}
	
	@RequestMapping("/SsNotice/deletenotice")//删
	public int deletenotice(@RequestBody int ssNid) {
		return noticeservice.deletenotice(ssNid);
	}
	
	@RequestMapping("/SsNotice/updateByssNid")//改
	public int updateByssNid(@RequestBody SsNotice record) {
		return noticeservice.updateByssNid(record);
	}
	
	@RequestMapping("/SsNotice/selectByssNid")//ssNid查,进入改
	public SsNotice selectByssNid(@RequestBody int ssNid) {
		return noticeservice.selectByssNid(ssNid);
	}
	
	@RequestMapping("/SsNotice/insertnotice")//加
	public int insertnotice(@RequestBody SsNotice record) {
		return noticeservice.insertnotice(record);
	}
	
	@RequestMapping("/SsNotice/selectnotciemohu")//搜索框内容模糊查
	public List<SsNotice> selectnotciemohu(@RequestBody String s) {	
		return noticeservice.selectnotciemohu(s);
	}
	
	@RequestMapping("/SsNotice/selectnotciemohu1")//搜索框内容模糊查
	public List<SsNotice> selectnotciemohu1(@RequestBody SsNotice ssnotice) {	
		return noticeservice.selectnotciemohu1(ssnotice);
	}
	
}
