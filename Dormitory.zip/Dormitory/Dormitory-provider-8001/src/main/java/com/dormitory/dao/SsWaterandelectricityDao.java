package com.dormitory.dao;

import com.dormitory.pojo.SsWaterandelectricity;
import com.dormitory.pojo.SsWaterandelectricityExample;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface SsWaterandelectricityDao {
    int countByExample(SsWaterandelectricityExample example);

    int deleteByExample(SsWaterandelectricityExample example);

    int deleteByPrimaryKey(Integer ssWeid);

    int insert(SsWaterandelectricity record);

    int insertSelective(SsWaterandelectricity record);

    List<SsWaterandelectricity> selectByExample(SsWaterandelectricityExample example);

    SsWaterandelectricity selectByPrimaryKey(Integer ssWeid);

    int updateByExampleSelective(@Param("record") SsWaterandelectricity record, @Param("example") SsWaterandelectricityExample example);

    int updateByExample(@Param("record") SsWaterandelectricity record, @Param("example") SsWaterandelectricityExample example);

    int updateByPrimaryKeySelective(SsWaterandelectricity record);

    int updateByPrimaryKey(SsWaterandelectricity record);
    
    //全查之宿舍升序
    List<SsWaterandelectricity> selWEandDorm();
    
    //ssWeid查
    SsWaterandelectricity selWEandDormByssWeid(Integer ssWeid);
    
    //ssDid查
    List<SsWaterandelectricity> selWEandDormandUserByssDid(Integer ssDid);
    
    //搜索框ssDname、ssWestate
    List<SsWaterandelectricity> selWEandUserandDormByssDnameandssWestate(String c);
    
}