package com.dormitory.service;

import java.util.List;
import com.dormitory.pojo.SsHygiene;

public interface ISsHygieneService {
	
	List<SsHygiene> selHygieneandDormandUserByssHdateDESCandssDname();//全查之时间降序,宿舍升序-→老师
	
	int deletehygiene(Integer ssHid);//删
	
	int updateByssHid(SsHygiene record,String ssDname);//改
	
	SsHygiene selHygieneandDormByssHid(Integer ssHid);//ssHid查,进入改
	
	List<SsHygiene> selHygieneandDormandUserByssDidandssHdateDESC(Integer ssDid);//ssDid查,日期降序-→学生
	
	List<SsHygiene> selHygieneandDormandUserByssDname(String s);//搜索框ssDname查
	
	void InsertHy();//群加

}
