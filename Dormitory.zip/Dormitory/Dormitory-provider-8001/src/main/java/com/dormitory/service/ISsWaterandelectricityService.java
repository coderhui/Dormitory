package com.dormitory.service;

import java.util.List;

import com.dormitory.pojo.SsWaterandelectricity;

public interface ISsWaterandelectricityService {
	
    List<SsWaterandelectricity> selWEandDorm();//全查之宿舍升序-→老师
	
    List<SsWaterandelectricity> selWEandDormandUserByssDid(Integer ssDid);//ssDid查-→学生
    
    List<SsWaterandelectricity> selWEandUserandDormByssDnameandssWestate(String c);//搜索框ssDname、ssWestate
    
    int UpdateWEState(int ssWeid,String ssWestate);//催交
    
    int UpdateWEwenum(int ssWeid,int ssEnum,int ssWnum,Double ssMoney);//改
    
    SsWaterandelectricity selWEandDormByssWeid(Integer ssWeid);//ssWeid查,进入改
}
