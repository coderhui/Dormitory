package com.dormitory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@SpringBootApplication
//启用事务
@EnableTransactionManagement
@EnableEurekaClient
public class DormitoryProvider_App {
	
	public static void main(String[] args) {
		SpringApplication.run(DormitoryProvider_App.class, args);		
		System.out.println("8001OK");
	}

}
