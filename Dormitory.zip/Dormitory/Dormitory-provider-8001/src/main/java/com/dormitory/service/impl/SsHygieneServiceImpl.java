package com.dormitory.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dormitory.dao.SsDormDao;
import com.dormitory.dao.SsHygieneDao;
import com.dormitory.dao.SsUserDao;
import com.dormitory.pojo.SsDorm;
import com.dormitory.pojo.SsHygiene;
import com.dormitory.pojo.SsUser;
import com.dormitory.pojo.SsUserExample;
import com.dormitory.service.ISsDormService;
import com.dormitory.service.ISsHygieneService;

@Service
public class SsHygieneServiceImpl implements ISsHygieneService {
	@Autowired
	private SsHygieneDao hygienedao;
	
	@Autowired
	private ISsDormService dormservice;
	
	@Autowired 
	private SsDormDao dormDao;
	
	@Autowired
	private SsUserDao userDao;

	@Override//全查之时间降序,宿舍升序-→老师
	public List<SsHygiene> selHygieneandDormandUserByssHdateDESCandssDname() {
		return hygienedao.selHygieneandDormandUserByssHdateDESCandssDname();
	}
	@Override//删
	public int deletehygiene(Integer ssHid) {
		return hygienedao.deleteByPrimaryKey(ssHid);
	}
	@Override//改
	public int updateByssHid(SsHygiene record,String ssDname) {
		List<SsDorm> ssdorm = dormservice.selectByssDname(ssDname);
		record.setSsDid(ssdorm.get(0).getSsDid());
		return hygienedao.updateByPrimaryKey(record);
	}
	@Override//ssHid查,进入改
	public SsHygiene selHygieneandDormByssHid(Integer ssHid) {
		return hygienedao.selHygieneandDormByssHid(ssHid);
	}
	@Override//ssDid查,日期降序-→学生
	public List<SsHygiene> selHygieneandDormandUserByssDidandssHdateDESC(Integer ssDid) {
		return hygienedao.selHygieneandDormandUserByssDidandssHdateDESC(ssDid);
	}
	@Override//搜索框ssDname查
	public List<SsHygiene> selHygieneandDormandUserByssDname(String s) {		
		return hygienedao.selHygieneandDormandUserByssDname(s);
	}
	@Override//增加评分
	public void InsertHy() {
		List<SsDorm> dorms = dormDao.selDormandUserall();//查找所有有用户的宿舍
		List<Integer> newhygienes = new ArrayList<Integer>();//添加一个数组放进新的宿舍评分
		List<SsHygiene> hygienes = hygienedao.selHygieneandDormandUserByssHdateDESCandssDname();//查找所有分数
		
		SsUserExample example = new SsUserExample();
		com.dormitory.pojo.SsUserExample.Criteria criteria = example.createCriteria();
		criteria.andSsPowerEqualTo(3);//排除宿管的宿舍
		List<SsUser> users = userDao.selectByExample(example);//查找所有用户 
		
		for (SsDorm ssDorm : dorms) {//循环宿舍
			boolean flag  = true;
			for (SsHygiene ssHygiene : hygienes) {//循环分数
				if(ssDorm.getSsDid() == ssHygiene.getSsDorm().getSsDid()) {//宿舍id等于分数的宿舍id
					String time1 = new SimpleDateFormat("yyyy年MM月dd日").format(new Date());//Date转换为String
					String time2 = new SimpleDateFormat("yyyy年MM月dd日").format(ssHygiene.getSsHdate());
					if(time1.equals(time2)) {//判断时间是否相等
						flag = false;
						break;
					}
				}
			}
			if(flag) {
				newhygienes.add(ssDorm.getSsDid());//时间不等则存宿舍id
			}
		}
		
		for (int i : newhygienes) {
			boolean flag = true;
			for (SsUser ssUser : users) {
				if(ssUser.getSsDid() == i) {
					flag = false;
					break;
				}
			}
			if(flag) {
				SsHygiene hy = new SsHygiene();
				hy.setSsDid(i);
				String d = new SimpleDateFormat("yyyy年MM月dd日").format(new Date());
				Date date = null;
				try {
					date = new SimpleDateFormat("yyyy年MM月dd日").parse(d);
				} catch (ParseException e) {
					e.printStackTrace();
				}
				hy.setSsHdate(date);
				hygienedao.insertSelective(hy);
			}	
		}
	}

}
