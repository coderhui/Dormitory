package com.dormitory.dao;

import com.dormitory.pojo.SsNotice;
import com.dormitory.pojo.SsNoticeExample;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface SsNoticeDao {
    int countByExample(SsNoticeExample example);

    int deleteByExample(SsNoticeExample example);

    int deleteByPrimaryKey(Integer ssNid);

    int insert(SsNotice record);

    int insertSelective(SsNotice record);

    List<SsNotice> selectByExample(SsNoticeExample example);

    SsNotice selectByPrimaryKey(Integer ssNid);

    int updateByExampleSelective(@Param("record") SsNotice record, @Param("example") SsNoticeExample example);

    int updateByExample(@Param("record") SsNotice record, @Param("example") SsNoticeExample example);

    int updateByPrimaryKeySelective(SsNotice record);

    int updateByPrimaryKey(SsNotice record);

}