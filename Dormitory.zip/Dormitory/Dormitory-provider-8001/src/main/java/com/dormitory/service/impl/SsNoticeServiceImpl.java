package com.dormitory.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.dormitory.dao.SsNoticeDao;
import com.dormitory.pojo.SsNotice;
import com.dormitory.pojo.SsNoticeExample;
import com.dormitory.pojo.SsNoticeExample.Criteria;
import com.dormitory.service.ISsNoticeService;

@Service
public class SsNoticeServiceImpl implements ISsNoticeService {
	@Autowired
	private SsNoticeDao noticedao;

	@Override //全查之时间降序
	public List<SsNotice> selectByssNdateDESC() {
		SsNoticeExample example = new SsNoticeExample();
		example.setOrderByClause("ss_ndate DESC");
		return noticedao.selectByExample(example);
	}
	@Override //删
	public int deletenotice(Integer ssNid) {
		return noticedao.deleteByPrimaryKey(ssNid);
	}
	@Override //改
	public int updateByssNid(SsNotice record) {
		return noticedao.updateByPrimaryKey(record);
	}
	@Override //ssNid查,进入改
	public SsNotice selectByssNid(Integer ssNid) {
		return noticedao.selectByPrimaryKey(ssNid);
	}
	@Override //加
	public int insertnotice(SsNotice record) {
		return noticedao.insert(record);
	}
	@Override //内容模糊查
	public List<SsNotice> selectnotciemohu(String q) {
		SsNoticeExample example = new SsNoticeExample();
		Criteria criteria = example.createCriteria();
		if (q != null && !"".equals(q)) {
			criteria.andSsNnrLike("%" + q + "%");
		}
		return noticedao.selectByExample(example);
	}
	@Override //内容模糊查
	public List<SsNotice> selectnotciemohu1(SsNotice ssnotice) {
		SsNoticeExample example = new SsNoticeExample();
		Criteria criteria = example.createCriteria();
		if (ssnotice.getSsNnr() != null && !"".equals(ssnotice.getSsNnr())) {
			criteria.andSsNnrLike("%" + ssnotice.getSsNnr() + "%");
		}
		return noticedao.selectByExample(example);
	}

}
