package com.dormitory.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dormitory.pojo.SsUser;
import com.dormitory.pojo.SsViolation;
import com.dormitory.service.ISsUserService;
import com.dormitory.service.ISsViolationService;

@RestController
@RequestMapping("/SsViolation")
public class SsViolationController {
	
	@Autowired
	private ISsViolationService violationService;
	@Autowired
	private ISsUserService userService;
	
	@RequestMapping("/FindViolationMesByUid")
	public List<SsViolation> FindViolationMesByUid(@RequestBody int ssUid){//按用户id查找违规
		return violationService.FindViolationMesByUid(ssUid);
	}
	
	@RequestMapping("/UpdateViolationState/{ssVid}/{state}")
	public int UpdateViolationState(@PathVariable int ssVid,@PathVariable String state) {//修改违规状态
		return violationService.UpdateViolationState(ssVid, state);
	}
	
	@RequestMapping("/FindAllViolationMes")
	public List<SsViolation> FindAllViolationMes(){//查找所有违规记录
		return violationService.FindAllViolationMes();
	}
	
	@RequestMapping("/FindViolation")
	public List<SsViolation> FindViolation(@RequestBody String s){//查找违规记录
		return violationService.FindViolation(s);
	}
	
	@RequestMapping("/AddViolation")
	public int AddViolation(@RequestBody SsViolation ssViolation) {//添加违规
		return violationService.AddViolation(ssViolation);
	}
	
	@RequestMapping("/FindUserByUname")
	public SsUser FindUserByUname(@RequestBody String ssUname) {//按用户名查找用户
		return userService.FindUserByUname(ssUname);
	}
}
