package com.dormitory.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dormitory.dao.SsRepairDao;
import com.dormitory.pojo.SsRepair;
import com.dormitory.service.ISsRepairService;

import coms.Commons;

@Service
public class SsRepairServiceImpl implements ISsRepairService{
	@Autowired
	private SsRepairDao repairDao;
	
	@Override
	public List<SsRepair> FindAllRepairMes() {//查找所有维修
		// TODO Auto-generated method stub
		List<SsRepair> list = repairDao.FindAllRepairAndDorm();
		String pic = Commons.pic;
		for (SsRepair ssRepair : list) {
			ssRepair.setSsRimage(pic+ssRepair.getSsRimage());//拼接图片服务器地址
		}
		return list;
	}

	@Override
	public int AddRepair(SsRepair ssRepair) {//插入维修申请
		// TODO Auto-generated method stub
		return repairDao.insertSelective(ssRepair);
	}

	@Override
	public int UpdateRepairState(int ssRid, String ssRstate) {//修改维修状态
		// TODO Auto-generated method stub
		SsRepair repair = new SsRepair();
		repair.setSsRid(ssRid);
		repair.setSsRstate(ssRstate);
		return repairDao.updateByPrimaryKeySelective(repair);
	}

	@Override
	public List<SsRepair> FindRepairMesByState(String state) {//按状态查找维修记录
		// TODO Auto-generated method stub
		List<SsRepair> list = repairDao.FindRepairByState(state);
		String pic = Commons.pic;
		for (SsRepair ssRepair : list) {
			ssRepair.setSsRimage(pic+ssRepair.getSsRimage());
		}
		return list;
	}

	@Override
	public List<SsRepair> FindRepairAndDormByDid(int ssDid) {//根据ssDid查找宿舍维修信息
		// TODO Auto-generated method stub
		List<SsRepair> list = repairDao.FindRepairAndDormByDid(ssDid);
		String pic = Commons.pic;
		for (SsRepair ssRepair : list) {
			ssRepair.setSsRimage(pic+ssRepair.getSsRimage());
		}
		return list;
	}

}
