package com.dormitory.dao;

import com.dormitory.pojo.SsSubscribe;
import com.dormitory.pojo.SsSubscribeExample;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface SsSubscribeDao {
    int countByExample(SsSubscribeExample example);

    int deleteByExample(SsSubscribeExample example);

    int deleteByPrimaryKey(Integer ssSid);

    int insert(SsSubscribe record);

    int insertSelective(SsSubscribe record);

    List<SsSubscribe> selectByExample(SsSubscribeExample example);

    SsSubscribe selectByPrimaryKey(Integer ssSid);

    int updateByExampleSelective(@Param("record") SsSubscribe record, @Param("example") SsSubscribeExample example);

    int updateByExample(@Param("record") SsSubscribe record, @Param("example") SsSubscribeExample example);

    int updateByPrimaryKeySelective(SsSubscribe record);

    int updateByPrimaryKey(SsSubscribe record);
    
    List<SsSubscribe> FindAllSubscribe();//查找所有买水记录
}