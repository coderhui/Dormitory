package com.dormitory.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dormitory.dao.SsViolationDao;
import com.dormitory.pojo.SsViolation;
import com.dormitory.service.ISsViolationService;

@Service
public class SsViolationServiceImpl implements ISsViolationService{
	@Autowired
	private SsViolationDao violationDao;
	
	@Override
	public List<SsViolation> FindAllViolationMes() {//查找所有违规信息
		// TODO Auto-generated method stub
		return violationDao.FindAllViolation();
	}

	@Override
	public List<SsViolation> FindViolationMesByUid(int ssUid) {//按用户id查找违规记录
		// TODO Auto-generated method stub
		return violationDao.FindViolationMesByUid(ssUid);
	}

	@Override
	public int AddViolation(SsViolation ssViolation) {//插入违规记录
		// TODO Auto-generated method stub
		return violationDao.insertSelective(ssViolation);
	}

	@Override
	public int UpdateViolationState(int ssVid, String state) {//修改违规状态
		// TODO Auto-generated method stub
		SsViolation violation = new SsViolation();
		violation.setSsVid(ssVid);
		violation.setSsVstate(state);
		return violationDao.updateByPrimaryKeySelective(violation);
	}

	@Override
	public List<SsViolation> FindViolation(String s) {//查找违规
		// TODO Auto-generated method stub
		return violationDao.FindViolation(s);
	}

}
