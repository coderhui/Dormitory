package com.dormitory.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dormitory.dao.SsDormDao;
import com.dormitory.pojo.SsDorm;
import com.dormitory.pojo.SsDormExample;
import com.dormitory.pojo.SsDormExample.Criteria;
import com.dormitory.service.ISsDormService;

@Service
public class SsDormServiceImpl implements ISsDormService{
	@Autowired
	private SsDormDao dormDao;
	
	@Override
	public List<SsDorm> FindAllDorm() {//查找所有宿舍
		// TODO Auto-generated method stub
		return dormDao.findAllDorm();
	}
	
	@Override//按ssDname查ssDid
	public List<SsDorm> selectByssDname(String ssDname) {
		SsDormExample example = new SsDormExample();
		Criteria criteria = example.createCriteria();
		criteria.andSsDnameEqualTo(ssDname);
		return dormDao.selectByExample(example);
	}

	@Override
	public List<SsDorm> selDormandUserall() {
		return dormDao.selDormandUserall();
	}

}
