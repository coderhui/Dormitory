package com.dormitory.service;

import java.util.List;

import com.dormitory.pojo.SsViolation;

public interface ISsViolationService {
	List<SsViolation> FindViolationMesByUid(int ssUid);//按用户id查找违规记录
	
	List<SsViolation> FindAllViolationMes();//查找所有违规信息
	
	int AddViolation(SsViolation ssViolation);//插入违规记录
	
	int UpdateViolationState(int ssVid,String state);//修改违规状态
	
	List<SsViolation> FindViolation(String s);//查找违规
}
