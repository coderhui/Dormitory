package com.dormitory.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.dormitory.pojo.SsWaterandelectricity;
import com.dormitory.service.ISsWaterandelectricityService;

@RestController
public class SsWaterandelectricityController {
	@Autowired
	private ISsWaterandelectricityService weservice;
	
	@RequestMapping("/SsWaterandelectricity/selWEandDorm")//全查之宿舍升序-→老师
	public List<SsWaterandelectricity> selWEandDorm() {
		return weservice.selWEandDorm();
	}
	
	@RequestMapping("/SsWaterandelectricity/selWEandDormandUserByssDid")//ssDid查-→学生
	public List<SsWaterandelectricity> selWEandDormandUserByssDid(@RequestBody int ssDid) {
		return weservice.selWEandDormandUserByssDid(ssDid);
	}
	
	@RequestMapping("/SsWaterandelectricity/selWEandUserandDormByssDnameandssWestate")//搜索框ssDname、ssWestate
	public List<SsWaterandelectricity> selWEandUserandDormByssDnameandssWestate(@RequestBody String c) {
		return weservice.selWEandUserandDormByssDnameandssWestate(c);
	}
	
	@RequestMapping("/SsWaterandelectricity/UpdateWEState/{ssWeid}/{ssWestate}")//催交
	public int UpdateWEState(@PathVariable int ssWeid, @PathVariable String ssWestate) {
		return weservice.UpdateWEState(ssWeid, ssWestate);
	}
	
	@RequestMapping("/SsWaterandelectricity/UpdateWEwenum/{ssWeid}/{ssEnum}/{ssWnum}/{ssMoney}")//改
	public int UpdateWEwenum(@PathVariable int ssWeid, @PathVariable int ssEnum, @PathVariable int ssWnum,@PathVariable Double ssMoney) {
		return weservice.UpdateWEwenum(ssWeid, ssEnum, ssWnum, ssMoney);
	}
	
	@RequestMapping("/SsWaterandelectricity/selWEandDormByssWeid")//ssWeid查,进入改
	public SsWaterandelectricity selWEandDormByssWeid(@RequestBody int ssWeid) {
		return weservice.selWEandDormByssWeid(ssWeid);
	}

}
