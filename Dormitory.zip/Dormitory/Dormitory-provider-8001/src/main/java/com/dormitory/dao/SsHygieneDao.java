package com.dormitory.dao;

import com.dormitory.pojo.SsHygiene;
import com.dormitory.pojo.SsHygieneExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface SsHygieneDao {
    int countByExample(SsHygieneExample example);

    int deleteByExample(SsHygieneExample example);

    int deleteByPrimaryKey(Integer ssHid);

    int insert(SsHygiene record);

    int insertSelective(SsHygiene record);

    List<SsHygiene> selectByExample(SsHygieneExample example);

    SsHygiene selectByPrimaryKey(Integer ssHid);

    int updateByExampleSelective(@Param("record") SsHygiene record, @Param("example") SsHygieneExample example);

    int updateByExample(@Param("record") SsHygiene record, @Param("example") SsHygieneExample example);

    int updateByPrimaryKeySelective(SsHygiene record);

    int updateByPrimaryKey(SsHygiene record);
       
    SsHygiene selHygieneandDormByssHid(Integer ssHid);//ssHid查
       
    List<SsHygiene> selHygieneandDormandUserByssDidandssHdateDESC(Integer ssDid);//ssDid查,日期降序
     
    List<SsHygiene> selHygieneandDormandUserByssDname(String s);//搜索框ssDname查
    
    List<SsHygiene> selHygieneandDormandUserByssHdateDESCandssDname();//全查之时间降序,宿舍升序
    
}