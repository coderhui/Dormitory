package com.dormitory.dao;

import com.dormitory.pojo.SsDorm;
import com.dormitory.pojo.SsDormExample;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface SsDormDao {
    int countByExample(SsDormExample example);

    int deleteByExample(SsDormExample example);

    int deleteByPrimaryKey(Integer ssDid);

    int insert(SsDorm record);

    int insertSelective(SsDorm record);

    List<SsDorm> selectByExample(SsDormExample example);

    SsDorm selectByPrimaryKey(Integer ssDid);

    int updateByExampleSelective(@Param("record") SsDorm record, @Param("example") SsDormExample example);

    int updateByExample(@Param("record") SsDorm record, @Param("example") SsDormExample example);

    int updateByPrimaryKeySelective(SsDorm record);

    int updateByPrimaryKey(SsDorm record);
    
    List<SsDorm> findAllDorm();
    
    List<SsDorm> selDormandUserall();
}