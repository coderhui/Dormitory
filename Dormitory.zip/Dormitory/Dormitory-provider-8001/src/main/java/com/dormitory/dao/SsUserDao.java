package com.dormitory.dao;

import com.dormitory.pojo.SsUser;
import com.dormitory.pojo.SsUserExample;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface SsUserDao {
    int countByExample(SsUserExample example);

    int deleteByExample(SsUserExample example);

    int deleteByPrimaryKey(Integer ssUid);

    int insert(SsUser record);

    int insertSelective(SsUser record);

    List<SsUser> selectByExample(SsUserExample example);

    SsUser selectByPrimaryKey(Integer ssUid);

    int updateByExampleSelective(@Param("record") SsUser record, @Param("example") SsUserExample example);

    int updateByExample(@Param("record") SsUser record, @Param("example") SsUserExample example);

    int updateByPrimaryKeySelective(SsUser record);

    int updateByPrimaryKey(SsUser record);
    
    SsUser findUserAndDorm(int ssUid);
    
    List<SsUser> findUserAndDormMes();//查找所有用户(包括宿舍信息)
    
    List<SsUser> findUserAndDormMesByDid(int ssDid);//根据宿舍号did查找宿舍人员信息
}