package com.dormitory.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dormitory.pojo.SsSubscribe;
import com.dormitory.pojo.SsUser;
import com.dormitory.service.ISsSubscribeService;
import com.dormitory.service.ISsUserService;


@RestController
@RequestMapping("/SsSubscribe")
public class SsSubscribeController {
	@Autowired
	private ISsSubscribeService service;
	
	@Autowired
	private ISsUserService userService;
	
	@RequestMapping("/FindUserAllMes")
	public SsUser FindUserAllMes(@RequestBody int ssUid) {//根据用户id查找用户信息
		return userService.FindUserAllMes(ssUid);
	}
	
	@RequestMapping("/BuyWaterAndTo")
	public boolean BuyWaterAndTo(@RequestBody int ssUid) {//买水并配送
		service.BuyWaterAndTo(ssUid);
		return true;
	}
	
	@RequestMapping("/BuyWater")
	public boolean BuyWater(@RequestBody int ssUid) {//买水
		service.BuyWater(ssUid);
		return true;
	}
	
	@RequestMapping("/FindAllSubscribe")
	public List<SsSubscribe> FindAllSubscribe(){
		return service.FindAllSubscirbe();
	}
	
	@RequestMapping("/UpdateSsStatus/{ssSid}/{status}")
	public int UpdateSsStatus(@PathVariable int ssSid, @PathVariable String status) {//修改买水状态
		return service.UpdateSsStatus(ssSid, status);
	}
}
