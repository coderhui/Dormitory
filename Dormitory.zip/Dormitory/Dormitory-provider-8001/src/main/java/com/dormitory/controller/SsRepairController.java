package com.dormitory.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.dormitory.pojo.SsRepair;
import com.dormitory.service.ISsRepairService;




@RestController
@RequestMapping("/SsRepair")
public class SsRepairController {
	
	@Autowired
	private ISsRepairService repairService;
	
	@RequestMapping("/FindRepairMesByDid")
	public List<SsRepair> FindRepairMesByUid(@RequestBody int ssDid){//查找所有维修记录
		return repairService.FindRepairAndDormByDid(ssDid);
	}
	
	@RequestMapping("/AddRepair")
	public boolean AddRepair(@RequestBody SsRepair ssRepair) {//插入维修记录
		repairService.AddRepair(ssRepair);
		return true;
	}
	
	@RequestMapping("/FindAllRepair")
	public List<SsRepair> FindAllRepair(){
		return repairService.FindAllRepairMes();
	}
	
	@RequestMapping("/FindRepairMesByState")
	public List<SsRepair> FindRepairMesByState(){//根据状态查找维修记录
		return repairService.FindRepairMesByState("受理中");
	}
	
	@RequestMapping("/UpdateRepairState/{ssRid}/{ssRstate}")
	public boolean UpdateRepairState(@PathVariable int ssRid,@PathVariable String ssRstate) {//修改维修状态
		repairService.UpdateRepairState(ssRid, ssRstate);
		return true;
	}
}
