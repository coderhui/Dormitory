package com.dormitory.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.dormitory.dao.SsWaterandelectricityDao;
import com.dormitory.pojo.SsWaterandelectricity;
import com.dormitory.service.ISsWaterandelectricityService;

@Service
public class SsWaterandelectricityServiceImpl implements ISsWaterandelectricityService{
	@Autowired
	private SsWaterandelectricityDao wedao;

	@Override//全查之宿舍升序-→老师
	public List<SsWaterandelectricity> selWEandDorm() {
		return wedao.selWEandDorm();
	}
	@Override//ssDid查-→学生
	public List<SsWaterandelectricity> selWEandDormandUserByssDid(Integer ssDid) {
		return wedao.selWEandDormandUserByssDid(ssDid);
	}
	@Override//搜索框ssDname、ssWestate
	public List<SsWaterandelectricity> selWEandUserandDormByssDnameandssWestate(String c) {
		return wedao.selWEandUserandDormByssDnameandssWestate(c);
	}
	@Override//催交
	public int UpdateWEState(int ssWeid, String ssWestate) {
		SsWaterandelectricity sswe = new SsWaterandelectricity();
		sswe.setSsWeid(ssWeid);
		sswe.setSsWestate(ssWestate);
		return wedao.updateByPrimaryKeySelective(sswe);
	}
	@Override//改
	public int UpdateWEwenum(int ssWeid, int ssEnum, int ssWnum,Double ssMoney) {
		SsWaterandelectricity sswe = new SsWaterandelectricity();
		sswe.setSsWeid(ssWeid);
		sswe.setSsEnum(ssEnum);
		sswe.setSsWnum(ssWnum);
		sswe.setSsMoney(Double.valueOf(sswe.getSsEnum())+Double.valueOf(sswe.getSsWnum()));
		return wedao.updateByPrimaryKeySelective(sswe);
	}
	@Override//ssWeid查,进入改
	public SsWaterandelectricity selWEandDormByssWeid(Integer ssWeid) {
		return wedao.selWEandDormByssWeid(ssWeid);
	}
	
}
