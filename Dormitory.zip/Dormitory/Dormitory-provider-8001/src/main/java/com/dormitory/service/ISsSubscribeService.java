package com.dormitory.service;

import java.util.List;

import com.dormitory.pojo.SsSubscribe;

public interface ISsSubscribeService {
	void BuyWater(int ssUid);//买水
	
	void BuyWaterAndTo(int ssUid);//买水并送上门
	
	List<SsSubscribe> FindAllSubscirbe();//查找所有买水记录
	
	int UpdateSsStatus(int ssSid,String status);//修改买水状态
}
