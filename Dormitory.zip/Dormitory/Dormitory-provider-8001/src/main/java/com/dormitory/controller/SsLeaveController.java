package com.dormitory.controller;

import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.dormitory.pojo.SsLeave;
import com.dormitory.service.ISsLeaveService;

@RestController
public class SsLeaveController {
	@Autowired 
	private ISsLeaveService leaveservice;

	@RequestMapping("/SsLeave/selLeaveandUserandDormByssLwdateDESCandssDname")//全查之离返日期降序,宿舍升序-→老师
	public List<SsLeave> selLeaveandUserandDormByssLwdateDESCandssDname() {
		return leaveservice.selLeaveandUserandDormByssLwdateDESCandssDname();
	}
	
	@RequestMapping("/SsLeave/selLeaveandUserandDormByssUidandsslwdateDESC")//ssUid查,ss_Lwdate、ss_lbdate降序-→学生
	public List<SsLeave> selLeaveandUserandDormByssUidandsslwdateDESC(@RequestBody int ssUid) {		
		return leaveservice.selLeaveandUserandDormByssUidandsslwdateDESC(ssUid);
	}
	
	@RequestMapping("/SsLeave/selLeaveandUserandDormByssUnameandssDname")//搜索框ssUname、ssDname查
	public List<SsLeave> selLeaveandUserandDormByssUnameandssDname(@RequestBody String b) {
		return leaveservice.selLeaveandUserandDormByssUnameandssDname(b);
	}
	
	@RequestMapping("/SsLeave/UpdateLeave/{ssLid}/{ssLwdate}/{ssLbdate}/{ssLstatus}")//改
	public int UpdateLeave(@PathVariable int ssLid, @PathVariable Date ssLwdate, @PathVariable Date ssLbdate, @PathVariable String ssLstatus) {
		return leaveservice.UpdateLeave(ssLid, ssLwdate, ssLbdate, ssLstatus);
	}
	
	@RequestMapping("/SsLeave/selLeaveandUserandDormByssLid")//ssLid查,进入改
	public SsLeave selLeaveandUserandDormByssLid(@RequestBody int ssLid) {
		return leaveservice.selLeaveandUserandDormByssLid(ssLid);
	}
	
	@RequestMapping("/SsLeave/insertSelective")//加
	public int insertSelective(@RequestBody SsLeave record) {
		return leaveservice.insertSelective(record);
	}
	
}
