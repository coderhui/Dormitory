package com.dormitory.service;

import java.util.List;

import com.dormitory.pojo.SsUser;

public interface ISsUserService {
	SsUser FindUserByNameAndPw(String username,String password);//查找用户
	
	boolean CheckUsername(String username);//验证用户名
	
	boolean CheckPassword(String username,String password);//验证密码
	
	int AddUser(SsUser user);//插入用户
	
	SsUser FindUserAllMes(int uid);//查找用户信息
	
	int UpdateUser(SsUser user);//修改用户
	
	boolean CheckEmail(String username,String email);//验证邮箱
	
	SsUser FindUserByNameAndEmail(String username,String email);//按照邮箱和用户名查找密码
	
	List<SsUser> FindAllUserMes();//查找所有用户
	
	List<SsUser> FindAllUserAndDormMes();//查找所有用户信息(包括宿舍信息)
	
	//按ssUname查ssUid
	List<SsUser> selectByssUname(String ssUname);
	
	List<SsUser> FindUserAndDormMesByDid(int ssDid);//根据did查找宿舍人员信息
	
	SsUser FindUserByUname(String ssUname);//按用户名查找用户
	
	boolean UpdateShezhang(String ssUname,int ssDid);//修改宿舍舍长

}
