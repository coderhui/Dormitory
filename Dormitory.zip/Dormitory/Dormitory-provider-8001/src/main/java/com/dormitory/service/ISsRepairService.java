package com.dormitory.service;

import java.util.List;

import com.dormitory.pojo.SsRepair;

public interface ISsRepairService {
	List<SsRepair> FindAllRepairMes();//查找所有维修
	
	int AddRepair(SsRepair ssRepair);//插入维修申请
	
	int UpdateRepairState(int ssRid,String ssRstate);//修改维修状态
	
	List<SsRepair> FindRepairMesByState(String state);//按状态查找维修记录
	
	List<SsRepair> FindRepairAndDormByDid(int ssDid);//根据ssDid查找宿舍维修信息
}
