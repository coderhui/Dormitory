package com.dormitory.dao;

import com.dormitory.pojo.SsRepair;
import com.dormitory.pojo.SsRepairExample;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface SsRepairDao {
    int countByExample(SsRepairExample example);

    int deleteByExample(SsRepairExample example);

    int deleteByPrimaryKey(Integer ssRid);

    int insert(SsRepair record);

    int insertSelective(SsRepair record);

    List<SsRepair> selectByExample(SsRepairExample example);

    SsRepair selectByPrimaryKey(Integer ssRid);

    int updateByExampleSelective(@Param("record") SsRepair record, @Param("example") SsRepairExample example);

    int updateByExample(@Param("record") SsRepair record, @Param("example") SsRepairExample example);

    int updateByPrimaryKeySelective(SsRepair record);

    int updateByPrimaryKey(SsRepair record);
    
    List<SsRepair> FindAllRepairAndDorm();//查看所有维修记录(包含宿舍)
    
    List<SsRepair> FindRepairByState(String state);//根据维修状态查找维修记录
    
    List<SsRepair> FindRepairAndDormByDid(int ssDid);//根据ssDiD查找宿舍维修记录
}