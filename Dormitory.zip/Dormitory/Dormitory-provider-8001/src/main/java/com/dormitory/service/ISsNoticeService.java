package com.dormitory.service;

import java.util.List;
import com.dormitory.pojo.SsNotice;

public interface ISsNoticeService {
	
    List<SsNotice> selectByssNdateDESC();//全查之时间降序
	
	int deletenotice(Integer ssNid);//删	
	
	int updateByssNid(SsNotice record);//改
	
	SsNotice selectByssNid(Integer ssNid);//ssNid查,进入改
	
	int insertnotice(SsNotice record);//加
	
    List<SsNotice> selectnotciemohu1(SsNotice ssnotice);//内容模糊查
	List<SsNotice> selectnotciemohu(String q);//内容模糊查
	
}
