package com.dormitory.pojo;

import java.util.Date;

public class SsRepair {
    private Integer ssRid;

    private Integer ssDid;

    private Date ssRdate;

    private String ssRnr;

    private String ssRimage;

    private String ssRstate;
    
    private SsDorm ssDorm;

    public SsDorm getSsDorm() {
		return ssDorm;
	}

	public void setSsDorm(SsDorm ssDorm) {
		this.ssDorm = ssDorm;
	}

	public Integer getSsRid() {
        return ssRid;
    }

    public void setSsRid(Integer ssRid) {
        this.ssRid = ssRid;
    }

    public Integer getSsDid() {
        return ssDid;
    }

    public void setSsDid(Integer ssDid) {
        this.ssDid = ssDid;
    }

    public Date getSsRdate() {
        return ssRdate;
    }

    public void setSsRdate(Date ssRdate) {
        this.ssRdate = ssRdate;
    }

    public String getSsRnr() {
        return ssRnr;
    }

    public void setSsRnr(String ssRnr) {
        this.ssRnr = ssRnr == null ? null : ssRnr.trim();
    }

    public String getSsRimage() {
        return ssRimage;
    }

    public void setSsRimage(String ssRimage) {
        this.ssRimage = ssRimage == null ? null : ssRimage.trim();
    }

    public String getSsRstate() {
        return ssRstate;
    }

    public void setSsRstate(String ssRstate) {
        this.ssRstate = ssRstate == null ? null : ssRstate.trim();
    }

	@Override
	public String toString() {
		return "SsRepair [ssRid=" + ssRid + ", ssDid=" + ssDid + ", ssRdate=" + ssRdate + ", ssRnr=" + ssRnr
				+ ", ssRimage=" + ssRimage + ", ssRstate=" + ssRstate + ", ssDorm=" + ssDorm + "]";
	}
}