package com.dormitory.pojo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SsHygieneExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public SsHygieneExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andSsHidIsNull() {
            addCriterion("ss_hid is null");
            return (Criteria) this;
        }

        public Criteria andSsHidIsNotNull() {
            addCriterion("ss_hid is not null");
            return (Criteria) this;
        }

        public Criteria andSsHidEqualTo(Integer value) {
            addCriterion("ss_hid =", value, "ssHid");
            return (Criteria) this;
        }

        public Criteria andSsHidNotEqualTo(Integer value) {
            addCriterion("ss_hid <>", value, "ssHid");
            return (Criteria) this;
        }

        public Criteria andSsHidGreaterThan(Integer value) {
            addCriterion("ss_hid >", value, "ssHid");
            return (Criteria) this;
        }

        public Criteria andSsHidGreaterThanOrEqualTo(Integer value) {
            addCriterion("ss_hid >=", value, "ssHid");
            return (Criteria) this;
        }

        public Criteria andSsHidLessThan(Integer value) {
            addCriterion("ss_hid <", value, "ssHid");
            return (Criteria) this;
        }

        public Criteria andSsHidLessThanOrEqualTo(Integer value) {
            addCriterion("ss_hid <=", value, "ssHid");
            return (Criteria) this;
        }

        public Criteria andSsHidIn(List<Integer> values) {
            addCriterion("ss_hid in", values, "ssHid");
            return (Criteria) this;
        }

        public Criteria andSsHidNotIn(List<Integer> values) {
            addCriterion("ss_hid not in", values, "ssHid");
            return (Criteria) this;
        }

        public Criteria andSsHidBetween(Integer value1, Integer value2) {
            addCriterion("ss_hid between", value1, value2, "ssHid");
            return (Criteria) this;
        }

        public Criteria andSsHidNotBetween(Integer value1, Integer value2) {
            addCriterion("ss_hid not between", value1, value2, "ssHid");
            return (Criteria) this;
        }

        public Criteria andSsDidIsNull() {
            addCriterion("ss_did is null");
            return (Criteria) this;
        }

        public Criteria andSsDidIsNotNull() {
            addCriterion("ss_did is not null");
            return (Criteria) this;
        }

        public Criteria andSsDidEqualTo(Integer value) {
            addCriterion("ss_did =", value, "ssDid");
            return (Criteria) this;
        }

        public Criteria andSsDidNotEqualTo(Integer value) {
            addCriterion("ss_did <>", value, "ssDid");
            return (Criteria) this;
        }

        public Criteria andSsDidGreaterThan(Integer value) {
            addCriterion("ss_did >", value, "ssDid");
            return (Criteria) this;
        }

        public Criteria andSsDidGreaterThanOrEqualTo(Integer value) {
            addCriterion("ss_did >=", value, "ssDid");
            return (Criteria) this;
        }

        public Criteria andSsDidLessThan(Integer value) {
            addCriterion("ss_did <", value, "ssDid");
            return (Criteria) this;
        }

        public Criteria andSsDidLessThanOrEqualTo(Integer value) {
            addCriterion("ss_did <=", value, "ssDid");
            return (Criteria) this;
        }

        public Criteria andSsDidIn(List<Integer> values) {
            addCriterion("ss_did in", values, "ssDid");
            return (Criteria) this;
        }

        public Criteria andSsDidNotIn(List<Integer> values) {
            addCriterion("ss_did not in", values, "ssDid");
            return (Criteria) this;
        }

        public Criteria andSsDidBetween(Integer value1, Integer value2) {
            addCriterion("ss_did between", value1, value2, "ssDid");
            return (Criteria) this;
        }

        public Criteria andSsDidNotBetween(Integer value1, Integer value2) {
            addCriterion("ss_did not between", value1, value2, "ssDid");
            return (Criteria) this;
        }

        public Criteria andSsBedIsNull() {
            addCriterion("ss_bed is null");
            return (Criteria) this;
        }

        public Criteria andSsBedIsNotNull() {
            addCriterion("ss_bed is not null");
            return (Criteria) this;
        }

        public Criteria andSsBedEqualTo(Integer value) {
            addCriterion("ss_bed =", value, "ssBed");
            return (Criteria) this;
        }

        public Criteria andSsBedNotEqualTo(Integer value) {
            addCriterion("ss_bed <>", value, "ssBed");
            return (Criteria) this;
        }

        public Criteria andSsBedGreaterThan(Integer value) {
            addCriterion("ss_bed >", value, "ssBed");
            return (Criteria) this;
        }

        public Criteria andSsBedGreaterThanOrEqualTo(Integer value) {
            addCriterion("ss_bed >=", value, "ssBed");
            return (Criteria) this;
        }

        public Criteria andSsBedLessThan(Integer value) {
            addCriterion("ss_bed <", value, "ssBed");
            return (Criteria) this;
        }

        public Criteria andSsBedLessThanOrEqualTo(Integer value) {
            addCriterion("ss_bed <=", value, "ssBed");
            return (Criteria) this;
        }

        public Criteria andSsBedIn(List<Integer> values) {
            addCriterion("ss_bed in", values, "ssBed");
            return (Criteria) this;
        }

        public Criteria andSsBedNotIn(List<Integer> values) {
            addCriterion("ss_bed not in", values, "ssBed");
            return (Criteria) this;
        }

        public Criteria andSsBedBetween(Integer value1, Integer value2) {
            addCriterion("ss_bed between", value1, value2, "ssBed");
            return (Criteria) this;
        }

        public Criteria andSsBedNotBetween(Integer value1, Integer value2) {
            addCriterion("ss_bed not between", value1, value2, "ssBed");
            return (Criteria) this;
        }

        public Criteria andSsChIsNull() {
            addCriterion("ss_ch is null");
            return (Criteria) this;
        }

        public Criteria andSsChIsNotNull() {
            addCriterion("ss_ch is not null");
            return (Criteria) this;
        }

        public Criteria andSsChEqualTo(Integer value) {
            addCriterion("ss_ch =", value, "ssCh");
            return (Criteria) this;
        }

        public Criteria andSsChNotEqualTo(Integer value) {
            addCriterion("ss_ch <>", value, "ssCh");
            return (Criteria) this;
        }

        public Criteria andSsChGreaterThan(Integer value) {
            addCriterion("ss_ch >", value, "ssCh");
            return (Criteria) this;
        }

        public Criteria andSsChGreaterThanOrEqualTo(Integer value) {
            addCriterion("ss_ch >=", value, "ssCh");
            return (Criteria) this;
        }

        public Criteria andSsChLessThan(Integer value) {
            addCriterion("ss_ch <", value, "ssCh");
            return (Criteria) this;
        }

        public Criteria andSsChLessThanOrEqualTo(Integer value) {
            addCriterion("ss_ch <=", value, "ssCh");
            return (Criteria) this;
        }

        public Criteria andSsChIn(List<Integer> values) {
            addCriterion("ss_ch in", values, "ssCh");
            return (Criteria) this;
        }

        public Criteria andSsChNotIn(List<Integer> values) {
            addCriterion("ss_ch not in", values, "ssCh");
            return (Criteria) this;
        }

        public Criteria andSsChBetween(Integer value1, Integer value2) {
            addCriterion("ss_ch between", value1, value2, "ssCh");
            return (Criteria) this;
        }

        public Criteria andSsChNotBetween(Integer value1, Integer value2) {
            addCriterion("ss_ch not between", value1, value2, "ssCh");
            return (Criteria) this;
        }

        public Criteria andSsYtIsNull() {
            addCriterion("ss_yt is null");
            return (Criteria) this;
        }

        public Criteria andSsYtIsNotNull() {
            addCriterion("ss_yt is not null");
            return (Criteria) this;
        }

        public Criteria andSsYtEqualTo(Integer value) {
            addCriterion("ss_yt =", value, "ssYt");
            return (Criteria) this;
        }

        public Criteria andSsYtNotEqualTo(Integer value) {
            addCriterion("ss_yt <>", value, "ssYt");
            return (Criteria) this;
        }

        public Criteria andSsYtGreaterThan(Integer value) {
            addCriterion("ss_yt >", value, "ssYt");
            return (Criteria) this;
        }

        public Criteria andSsYtGreaterThanOrEqualTo(Integer value) {
            addCriterion("ss_yt >=", value, "ssYt");
            return (Criteria) this;
        }

        public Criteria andSsYtLessThan(Integer value) {
            addCriterion("ss_yt <", value, "ssYt");
            return (Criteria) this;
        }

        public Criteria andSsYtLessThanOrEqualTo(Integer value) {
            addCriterion("ss_yt <=", value, "ssYt");
            return (Criteria) this;
        }

        public Criteria andSsYtIn(List<Integer> values) {
            addCriterion("ss_yt in", values, "ssYt");
            return (Criteria) this;
        }

        public Criteria andSsYtNotIn(List<Integer> values) {
            addCriterion("ss_yt not in", values, "ssYt");
            return (Criteria) this;
        }

        public Criteria andSsYtBetween(Integer value1, Integer value2) {
            addCriterion("ss_yt between", value1, value2, "ssYt");
            return (Criteria) this;
        }

        public Criteria andSsYtNotBetween(Integer value1, Integer value2) {
            addCriterion("ss_yt not between", value1, value2, "ssYt");
            return (Criteria) this;
        }

        public Criteria andSsWcIsNull() {
            addCriterion("ss_wc is null");
            return (Criteria) this;
        }

        public Criteria andSsWcIsNotNull() {
            addCriterion("ss_wc is not null");
            return (Criteria) this;
        }

        public Criteria andSsWcEqualTo(Integer value) {
            addCriterion("ss_wc =", value, "ssWc");
            return (Criteria) this;
        }

        public Criteria andSsWcNotEqualTo(Integer value) {
            addCriterion("ss_wc <>", value, "ssWc");
            return (Criteria) this;
        }

        public Criteria andSsWcGreaterThan(Integer value) {
            addCriterion("ss_wc >", value, "ssWc");
            return (Criteria) this;
        }

        public Criteria andSsWcGreaterThanOrEqualTo(Integer value) {
            addCriterion("ss_wc >=", value, "ssWc");
            return (Criteria) this;
        }

        public Criteria andSsWcLessThan(Integer value) {
            addCriterion("ss_wc <", value, "ssWc");
            return (Criteria) this;
        }

        public Criteria andSsWcLessThanOrEqualTo(Integer value) {
            addCriterion("ss_wc <=", value, "ssWc");
            return (Criteria) this;
        }

        public Criteria andSsWcIn(List<Integer> values) {
            addCriterion("ss_wc in", values, "ssWc");
            return (Criteria) this;
        }

        public Criteria andSsWcNotIn(List<Integer> values) {
            addCriterion("ss_wc not in", values, "ssWc");
            return (Criteria) this;
        }

        public Criteria andSsWcBetween(Integer value1, Integer value2) {
            addCriterion("ss_wc between", value1, value2, "ssWc");
            return (Criteria) this;
        }

        public Criteria andSsWcNotBetween(Integer value1, Integer value2) {
            addCriterion("ss_wc not between", value1, value2, "ssWc");
            return (Criteria) this;
        }

        public Criteria andSsWsIsNull() {
            addCriterion("ss_ws is null");
            return (Criteria) this;
        }

        public Criteria andSsWsIsNotNull() {
            addCriterion("ss_ws is not null");
            return (Criteria) this;
        }

        public Criteria andSsWsEqualTo(Integer value) {
            addCriterion("ss_ws =", value, "ssWs");
            return (Criteria) this;
        }

        public Criteria andSsWsNotEqualTo(Integer value) {
            addCriterion("ss_ws <>", value, "ssWs");
            return (Criteria) this;
        }

        public Criteria andSsWsGreaterThan(Integer value) {
            addCriterion("ss_ws >", value, "ssWs");
            return (Criteria) this;
        }

        public Criteria andSsWsGreaterThanOrEqualTo(Integer value) {
            addCriterion("ss_ws >=", value, "ssWs");
            return (Criteria) this;
        }

        public Criteria andSsWsLessThan(Integer value) {
            addCriterion("ss_ws <", value, "ssWs");
            return (Criteria) this;
        }

        public Criteria andSsWsLessThanOrEqualTo(Integer value) {
            addCriterion("ss_ws <=", value, "ssWs");
            return (Criteria) this;
        }

        public Criteria andSsWsIn(List<Integer> values) {
            addCriterion("ss_ws in", values, "ssWs");
            return (Criteria) this;
        }

        public Criteria andSsWsNotIn(List<Integer> values) {
            addCriterion("ss_ws not in", values, "ssWs");
            return (Criteria) this;
        }

        public Criteria andSsWsBetween(Integer value1, Integer value2) {
            addCriterion("ss_ws between", value1, value2, "ssWs");
            return (Criteria) this;
        }

        public Criteria andSsWsNotBetween(Integer value1, Integer value2) {
            addCriterion("ss_ws not between", value1, value2, "ssWs");
            return (Criteria) this;
        }

        public Criteria andSsHnumIsNull() {
            addCriterion("ss_hnum is null");
            return (Criteria) this;
        }

        public Criteria andSsHnumIsNotNull() {
            addCriterion("ss_hnum is not null");
            return (Criteria) this;
        }

        public Criteria andSsHnumEqualTo(Integer value) {
            addCriterion("ss_hnum =", value, "ssHnum");
            return (Criteria) this;
        }

        public Criteria andSsHnumNotEqualTo(Integer value) {
            addCriterion("ss_hnum <>", value, "ssHnum");
            return (Criteria) this;
        }

        public Criteria andSsHnumGreaterThan(Integer value) {
            addCriterion("ss_hnum >", value, "ssHnum");
            return (Criteria) this;
        }

        public Criteria andSsHnumGreaterThanOrEqualTo(Integer value) {
            addCriterion("ss_hnum >=", value, "ssHnum");
            return (Criteria) this;
        }

        public Criteria andSsHnumLessThan(Integer value) {
            addCriterion("ss_hnum <", value, "ssHnum");
            return (Criteria) this;
        }

        public Criteria andSsHnumLessThanOrEqualTo(Integer value) {
            addCriterion("ss_hnum <=", value, "ssHnum");
            return (Criteria) this;
        }

        public Criteria andSsHnumIn(List<Integer> values) {
            addCriterion("ss_hnum in", values, "ssHnum");
            return (Criteria) this;
        }

        public Criteria andSsHnumNotIn(List<Integer> values) {
            addCriterion("ss_hnum not in", values, "ssHnum");
            return (Criteria) this;
        }

        public Criteria andSsHnumBetween(Integer value1, Integer value2) {
            addCriterion("ss_hnum between", value1, value2, "ssHnum");
            return (Criteria) this;
        }

        public Criteria andSsHnumNotBetween(Integer value1, Integer value2) {
            addCriterion("ss_hnum not between", value1, value2, "ssHnum");
            return (Criteria) this;
        }

        public Criteria andSsHdateIsNull() {
            addCriterion("ss_hdate is null");
            return (Criteria) this;
        }

        public Criteria andSsHdateIsNotNull() {
            addCriterion("ss_hdate is not null");
            return (Criteria) this;
        }

        public Criteria andSsHdateEqualTo(Date value) {
            addCriterion("ss_hdate =", value, "ssHdate");
            return (Criteria) this;
        }

        public Criteria andSsHdateNotEqualTo(Date value) {
            addCriterion("ss_hdate <>", value, "ssHdate");
            return (Criteria) this;
        }

        public Criteria andSsHdateGreaterThan(Date value) {
            addCriterion("ss_hdate >", value, "ssHdate");
            return (Criteria) this;
        }

        public Criteria andSsHdateGreaterThanOrEqualTo(Date value) {
            addCriterion("ss_hdate >=", value, "ssHdate");
            return (Criteria) this;
        }

        public Criteria andSsHdateLessThan(Date value) {
            addCriterion("ss_hdate <", value, "ssHdate");
            return (Criteria) this;
        }

        public Criteria andSsHdateLessThanOrEqualTo(Date value) {
            addCriterion("ss_hdate <=", value, "ssHdate");
            return (Criteria) this;
        }

        public Criteria andSsHdateIn(List<Date> values) {
            addCriterion("ss_hdate in", values, "ssHdate");
            return (Criteria) this;
        }

        public Criteria andSsHdateNotIn(List<Date> values) {
            addCriterion("ss_hdate not in", values, "ssHdate");
            return (Criteria) this;
        }

        public Criteria andSsHdateBetween(Date value1, Date value2) {
            addCriterion("ss_hdate between", value1, value2, "ssHdate");
            return (Criteria) this;
        }

        public Criteria andSsHdateNotBetween(Date value1, Date value2) {
            addCriterion("ss_hdate not between", value1, value2, "ssHdate");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}