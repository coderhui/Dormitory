package com.dormitory.pojo;

public class SsSubscribe {
    private Integer ssSid;

    private Integer ssUid;

    private String ssSnr;

    private Double ssScost;

    private String ssSto;

    private String ssSstatus;

    public Integer getSsSid() {
        return ssSid;
    }

    public void setSsSid(Integer ssSid) {
        this.ssSid = ssSid;
    }

    public Integer getSsUid() {
        return ssUid;
    }

    public void setSsUid(Integer ssUid) {
        this.ssUid = ssUid;
    }

    public String getSsSnr() {
        return ssSnr;
    }

    public void setSsSnr(String ssSnr) {
        this.ssSnr = ssSnr == null ? null : ssSnr.trim();
    }

    public Double getSsScost() {
        return ssScost;
    }

    public void setSsScost(Double ssScost) {
        this.ssScost = ssScost;
    }

    public String getSsSto() {
        return ssSto;
    }

    public void setSsSto(String ssSto) {
        this.ssSto = ssSto == null ? null : ssSto.trim();
    }

    public String getSsSstatus() {
        return ssSstatus;
    }

    public void setSsSstatus(String ssSstatus) {
        this.ssSstatus = ssSstatus == null ? null : ssSstatus.trim();
    }
}