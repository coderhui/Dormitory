package com.dormitory.pojo;

import java.io.Serializable;

public class SsUser implements Serializable{
    private Integer ssUid;

    private String ssUname;

    private String ssPassword;

    private String ssSex;

    private String ssClass;

    private String ssEmail;

    private Integer ssDid;

    private Double ssMoney;

    private Integer ssPower;
    
    private SsDorm ssDorm;

    public SsDorm getSsDorm() {
		return ssDorm;
	}

	public void setSsDorm(SsDorm ssDorm) {
		this.ssDorm = ssDorm;
	}

	public Integer getSsUid() {
        return ssUid;
    }

    public void setSsUid(Integer ssUid) {
        this.ssUid = ssUid;
    }

    public String getSsUname() {
        return ssUname;
    }

    public void setSsUname(String ssUname) {
        this.ssUname = ssUname == null ? null : ssUname.trim();
    }

    public String getSsPassword() {
        return ssPassword;
    }

    public void setSsPassword(String ssPassword) {
        this.ssPassword = ssPassword == null ? null : ssPassword.trim();
    }

    public String getSsSex() {
        return ssSex;
    }

    public void setSsSex(String ssSex) {
        this.ssSex = ssSex == null ? null : ssSex.trim();
    }

    public String getSsClass() {
        return ssClass;
    }

    public void setSsClass(String ssClass) {
        this.ssClass = ssClass == null ? null : ssClass.trim();
    }

    public String getSsEmail() {
        return ssEmail;
    }

    public void setSsEmail(String ssEmail) {
        this.ssEmail = ssEmail == null ? null : ssEmail.trim();
    }

    public Integer getSsDid() {
        return ssDid;
    }

    public void setSsDid(Integer ssDid) {
        this.ssDid = ssDid;
    }

    public Double getSsMoney() {
        return ssMoney;
    }

    public void setSsMoney(Double ssMoney) {
        this.ssMoney = ssMoney;
    }

    public Integer getSsPower() {
        return ssPower;
    }

    public void setSsPower(Integer ssPower) {
        this.ssPower = ssPower;
    }

	@Override
	public String toString() {
		return "SsUser [ssUid=" + ssUid + ", ssUname=" + ssUname + ", ssPassword=" + ssPassword + ", ssSex=" + ssSex
				+ ", ssClass=" + ssClass + ", ssEmail=" + ssEmail + ", ssDid=" + ssDid + ", ssMoney=" + ssMoney
				+ ", ssPower=" + ssPower + ", ssDorm=" + ssDorm + "]";
	}
}