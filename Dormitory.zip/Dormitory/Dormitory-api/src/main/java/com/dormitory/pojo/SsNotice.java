package com.dormitory.pojo;

import java.util.Date;


public class SsNotice {
    private Integer ssNid;
    
   
    private Date ssNdate;

    private String ssNnr;

    public Integer getSsNid() {
        return ssNid;
    }

    public void setSsNid(Integer ssNid) {
        this.ssNid = ssNid;
    }

    public Date getSsNdate() {
        return ssNdate;
    }

    public void setSsNdate(Date ssNdate) {
        this.ssNdate = ssNdate;
    }

    public String getSsNnr() {
        return ssNnr;
    }

    public void setSsNnr(String ssNnr) {
        this.ssNnr = ssNnr == null ? null : ssNnr.trim();
    }
}