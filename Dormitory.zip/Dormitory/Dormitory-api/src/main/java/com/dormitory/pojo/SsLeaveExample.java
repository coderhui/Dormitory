package com.dormitory.pojo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SsLeaveExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public SsLeaveExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andSsLidIsNull() {
            addCriterion("ss_lid is null");
            return (Criteria) this;
        }

        public Criteria andSsLidIsNotNull() {
            addCriterion("ss_lid is not null");
            return (Criteria) this;
        }

        public Criteria andSsLidEqualTo(Integer value) {
            addCriterion("ss_lid =", value, "ssLid");
            return (Criteria) this;
        }

        public Criteria andSsLidNotEqualTo(Integer value) {
            addCriterion("ss_lid <>", value, "ssLid");
            return (Criteria) this;
        }

        public Criteria andSsLidGreaterThan(Integer value) {
            addCriterion("ss_lid >", value, "ssLid");
            return (Criteria) this;
        }

        public Criteria andSsLidGreaterThanOrEqualTo(Integer value) {
            addCriterion("ss_lid >=", value, "ssLid");
            return (Criteria) this;
        }

        public Criteria andSsLidLessThan(Integer value) {
            addCriterion("ss_lid <", value, "ssLid");
            return (Criteria) this;
        }

        public Criteria andSsLidLessThanOrEqualTo(Integer value) {
            addCriterion("ss_lid <=", value, "ssLid");
            return (Criteria) this;
        }

        public Criteria andSsLidIn(List<Integer> values) {
            addCriterion("ss_lid in", values, "ssLid");
            return (Criteria) this;
        }

        public Criteria andSsLidNotIn(List<Integer> values) {
            addCriterion("ss_lid not in", values, "ssLid");
            return (Criteria) this;
        }

        public Criteria andSsLidBetween(Integer value1, Integer value2) {
            addCriterion("ss_lid between", value1, value2, "ssLid");
            return (Criteria) this;
        }

        public Criteria andSsLidNotBetween(Integer value1, Integer value2) {
            addCriterion("ss_lid not between", value1, value2, "ssLid");
            return (Criteria) this;
        }

        public Criteria andSsUidIsNull() {
            addCriterion("ss_uid is null");
            return (Criteria) this;
        }

        public Criteria andSsUidIsNotNull() {
            addCriterion("ss_uid is not null");
            return (Criteria) this;
        }

        public Criteria andSsUidEqualTo(Integer value) {
            addCriterion("ss_uid =", value, "ssUid");
            return (Criteria) this;
        }

        public Criteria andSsUidNotEqualTo(Integer value) {
            addCriterion("ss_uid <>", value, "ssUid");
            return (Criteria) this;
        }

        public Criteria andSsUidGreaterThan(Integer value) {
            addCriterion("ss_uid >", value, "ssUid");
            return (Criteria) this;
        }

        public Criteria andSsUidGreaterThanOrEqualTo(Integer value) {
            addCriterion("ss_uid >=", value, "ssUid");
            return (Criteria) this;
        }

        public Criteria andSsUidLessThan(Integer value) {
            addCriterion("ss_uid <", value, "ssUid");
            return (Criteria) this;
        }

        public Criteria andSsUidLessThanOrEqualTo(Integer value) {
            addCriterion("ss_uid <=", value, "ssUid");
            return (Criteria) this;
        }

        public Criteria andSsUidIn(List<Integer> values) {
            addCriterion("ss_uid in", values, "ssUid");
            return (Criteria) this;
        }

        public Criteria andSsUidNotIn(List<Integer> values) {
            addCriterion("ss_uid not in", values, "ssUid");
            return (Criteria) this;
        }

        public Criteria andSsUidBetween(Integer value1, Integer value2) {
            addCriterion("ss_uid between", value1, value2, "ssUid");
            return (Criteria) this;
        }

        public Criteria andSsUidNotBetween(Integer value1, Integer value2) {
            addCriterion("ss_uid not between", value1, value2, "ssUid");
            return (Criteria) this;
        }

        public Criteria andSsLwdateIsNull() {
            addCriterion("ss_lwdate is null");
            return (Criteria) this;
        }

        public Criteria andSsLwdateIsNotNull() {
            addCriterion("ss_lwdate is not null");
            return (Criteria) this;
        }

        public Criteria andSsLwdateEqualTo(Date value) {
            addCriterion("ss_lwdate =", value, "ssLwdate");
            return (Criteria) this;
        }

        public Criteria andSsLwdateNotEqualTo(Date value) {
            addCriterion("ss_lwdate <>", value, "ssLwdate");
            return (Criteria) this;
        }

        public Criteria andSsLwdateGreaterThan(Date value) {
            addCriterion("ss_lwdate >", value, "ssLwdate");
            return (Criteria) this;
        }

        public Criteria andSsLwdateGreaterThanOrEqualTo(Date value) {
            addCriterion("ss_lwdate >=", value, "ssLwdate");
            return (Criteria) this;
        }

        public Criteria andSsLwdateLessThan(Date value) {
            addCriterion("ss_lwdate <", value, "ssLwdate");
            return (Criteria) this;
        }

        public Criteria andSsLwdateLessThanOrEqualTo(Date value) {
            addCriterion("ss_lwdate <=", value, "ssLwdate");
            return (Criteria) this;
        }

        public Criteria andSsLwdateIn(List<Date> values) {
            addCriterion("ss_lwdate in", values, "ssLwdate");
            return (Criteria) this;
        }

        public Criteria andSsLwdateNotIn(List<Date> values) {
            addCriterion("ss_lwdate not in", values, "ssLwdate");
            return (Criteria) this;
        }

        public Criteria andSsLwdateBetween(Date value1, Date value2) {
            addCriterion("ss_lwdate between", value1, value2, "ssLwdate");
            return (Criteria) this;
        }

        public Criteria andSsLwdateNotBetween(Date value1, Date value2) {
            addCriterion("ss_lwdate not between", value1, value2, "ssLwdate");
            return (Criteria) this;
        }

        public Criteria andSsLddateIsNull() {
            addCriterion("ss_lddate is null");
            return (Criteria) this;
        }

        public Criteria andSsLddateIsNotNull() {
            addCriterion("ss_lddate is not null");
            return (Criteria) this;
        }

        public Criteria andSsLddateEqualTo(Date value) {
            addCriterion("ss_lddate =", value, "ssLddate");
            return (Criteria) this;
        }

        public Criteria andSsLddateNotEqualTo(Date value) {
            addCriterion("ss_lddate <>", value, "ssLddate");
            return (Criteria) this;
        }

        public Criteria andSsLddateGreaterThan(Date value) {
            addCriterion("ss_lddate >", value, "ssLddate");
            return (Criteria) this;
        }

        public Criteria andSsLddateGreaterThanOrEqualTo(Date value) {
            addCriterion("ss_lddate >=", value, "ssLddate");
            return (Criteria) this;
        }

        public Criteria andSsLddateLessThan(Date value) {
            addCriterion("ss_lddate <", value, "ssLddate");
            return (Criteria) this;
        }

        public Criteria andSsLddateLessThanOrEqualTo(Date value) {
            addCriterion("ss_lddate <=", value, "ssLddate");
            return (Criteria) this;
        }

        public Criteria andSsLddateIn(List<Date> values) {
            addCriterion("ss_lddate in", values, "ssLddate");
            return (Criteria) this;
        }

        public Criteria andSsLddateNotIn(List<Date> values) {
            addCriterion("ss_lddate not in", values, "ssLddate");
            return (Criteria) this;
        }

        public Criteria andSsLddateBetween(Date value1, Date value2) {
            addCriterion("ss_lddate between", value1, value2, "ssLddate");
            return (Criteria) this;
        }

        public Criteria andSsLddateNotBetween(Date value1, Date value2) {
            addCriterion("ss_lddate not between", value1, value2, "ssLddate");
            return (Criteria) this;
        }

        public Criteria andSsLbdateIsNull() {
            addCriterion("ss_lbdate is null");
            return (Criteria) this;
        }

        public Criteria andSsLbdateIsNotNull() {
            addCriterion("ss_lbdate is not null");
            return (Criteria) this;
        }

        public Criteria andSsLbdateEqualTo(Date value) {
            addCriterion("ss_lbdate =", value, "ssLbdate");
            return (Criteria) this;
        }

        public Criteria andSsLbdateNotEqualTo(Date value) {
            addCriterion("ss_lbdate <>", value, "ssLbdate");
            return (Criteria) this;
        }

        public Criteria andSsLbdateGreaterThan(Date value) {
            addCriterion("ss_lbdate >", value, "ssLbdate");
            return (Criteria) this;
        }

        public Criteria andSsLbdateGreaterThanOrEqualTo(Date value) {
            addCriterion("ss_lbdate >=", value, "ssLbdate");
            return (Criteria) this;
        }

        public Criteria andSsLbdateLessThan(Date value) {
            addCriterion("ss_lbdate <", value, "ssLbdate");
            return (Criteria) this;
        }

        public Criteria andSsLbdateLessThanOrEqualTo(Date value) {
            addCriterion("ss_lbdate <=", value, "ssLbdate");
            return (Criteria) this;
        }

        public Criteria andSsLbdateIn(List<Date> values) {
            addCriterion("ss_lbdate in", values, "ssLbdate");
            return (Criteria) this;
        }

        public Criteria andSsLbdateNotIn(List<Date> values) {
            addCriterion("ss_lbdate not in", values, "ssLbdate");
            return (Criteria) this;
        }

        public Criteria andSsLbdateBetween(Date value1, Date value2) {
            addCriterion("ss_lbdate between", value1, value2, "ssLbdate");
            return (Criteria) this;
        }

        public Criteria andSsLbdateNotBetween(Date value1, Date value2) {
            addCriterion("ss_lbdate not between", value1, value2, "ssLbdate");
            return (Criteria) this;
        }

        public Criteria andSsLstatusIsNull() {
            addCriterion("ss_lstatus is null");
            return (Criteria) this;
        }

        public Criteria andSsLstatusIsNotNull() {
            addCriterion("ss_lstatus is not null");
            return (Criteria) this;
        }

        public Criteria andSsLstatusEqualTo(String value) {
            addCriterion("ss_lstatus =", value, "ssLstatus");
            return (Criteria) this;
        }

        public Criteria andSsLstatusNotEqualTo(String value) {
            addCriterion("ss_lstatus <>", value, "ssLstatus");
            return (Criteria) this;
        }

        public Criteria andSsLstatusGreaterThan(String value) {
            addCriterion("ss_lstatus >", value, "ssLstatus");
            return (Criteria) this;
        }

        public Criteria andSsLstatusGreaterThanOrEqualTo(String value) {
            addCriterion("ss_lstatus >=", value, "ssLstatus");
            return (Criteria) this;
        }

        public Criteria andSsLstatusLessThan(String value) {
            addCriterion("ss_lstatus <", value, "ssLstatus");
            return (Criteria) this;
        }

        public Criteria andSsLstatusLessThanOrEqualTo(String value) {
            addCriterion("ss_lstatus <=", value, "ssLstatus");
            return (Criteria) this;
        }

        public Criteria andSsLstatusLike(String value) {
            addCriterion("ss_lstatus like", value, "ssLstatus");
            return (Criteria) this;
        }

        public Criteria andSsLstatusNotLike(String value) {
            addCriterion("ss_lstatus not like", value, "ssLstatus");
            return (Criteria) this;
        }

        public Criteria andSsLstatusIn(List<String> values) {
            addCriterion("ss_lstatus in", values, "ssLstatus");
            return (Criteria) this;
        }

        public Criteria andSsLstatusNotIn(List<String> values) {
            addCriterion("ss_lstatus not in", values, "ssLstatus");
            return (Criteria) this;
        }

        public Criteria andSsLstatusBetween(String value1, String value2) {
            addCriterion("ss_lstatus between", value1, value2, "ssLstatus");
            return (Criteria) this;
        }

        public Criteria andSsLstatusNotBetween(String value1, String value2) {
            addCriterion("ss_lstatus not between", value1, value2, "ssLstatus");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}