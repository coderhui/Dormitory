package com.dormitory.pojo;

import java.util.Date;



public class SsHygiene {
    private Integer ssHid;

    private Integer ssDid;

    private Integer ssBed;

    private Integer ssCh;

    private Integer ssYt;

    private Integer ssWc;

    private Integer ssWs;

    private Integer ssHnum;

    
    private Date ssHdate;
    
    //以对象形式注入
    private SsDorm ssDorm;
    
    private SsUser ssUser;

	public Integer getSsHid() {
		return ssHid;
	}

	public void setSsHid(Integer ssHid) {
		this.ssHid = ssHid;
	}

	public Integer getSsDid() {
		return ssDid;
	}

	public void setSsDid(Integer ssDid) {
		this.ssDid = ssDid;
	}

	public Integer getSsBed() {
		return ssBed;
	}

	public void setSsBed(Integer ssBed) {
		this.ssBed = ssBed;
	}

	public Integer getSsCh() {
		return ssCh;
	}

	public void setSsCh(Integer ssCh) {
		this.ssCh = ssCh;
	}

	public Integer getSsYt() {
		return ssYt;
	}

	public void setSsYt(Integer ssYt) {
		this.ssYt = ssYt;
	}

	public Integer getSsWc() {
		return ssWc;
	}

	public void setSsWc(Integer ssWc) {
		this.ssWc = ssWc;
	}

	public Integer getSsWs() {
		return ssWs;
	}

	public void setSsWs(Integer ssWs) {
		this.ssWs = ssWs;
	}

	public Integer getSsHnum() {
		return ssHnum;
	}

	public void setSsHnum(Integer ssHnum) {
		this.ssHnum = ssHnum;
	}

	public Date getSsHdate() {
		return ssHdate;
	}

	public void setSsHdate(Date ssHdate) {
		this.ssHdate = ssHdate;
	}

	public SsDorm getSsDorm() {
		return ssDorm;
	}

	public void setSsDorm(SsDorm ssDorm) {
		this.ssDorm = ssDorm;
	}

	public SsUser getSsUser() {
		return ssUser;
	}

	public void setSsUser(SsUser ssUser) {
		this.ssUser = ssUser;
	}

	@Override
	public String toString() {
		return "SsHygiene [ssHid=" + ssHid + ", ssDid=" + ssDid + ", ssBed=" + ssBed + ", ssCh=" + ssCh + ", ssYt="
				+ ssYt + ", ssWc=" + ssWc + ", ssWs=" + ssWs + ", ssHnum=" + ssHnum + ", ssHdate=" + ssHdate
				+ ", ssDorm=" + ssDorm + ", ssUser=" + ssUser + "]";
	}

    
	
}