package com.dormitory.pojo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SsRepairExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public SsRepairExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andSsRidIsNull() {
            addCriterion("ss_rid is null");
            return (Criteria) this;
        }

        public Criteria andSsRidIsNotNull() {
            addCriterion("ss_rid is not null");
            return (Criteria) this;
        }

        public Criteria andSsRidEqualTo(Integer value) {
            addCriterion("ss_rid =", value, "ssRid");
            return (Criteria) this;
        }

        public Criteria andSsRidNotEqualTo(Integer value) {
            addCriterion("ss_rid <>", value, "ssRid");
            return (Criteria) this;
        }

        public Criteria andSsRidGreaterThan(Integer value) {
            addCriterion("ss_rid >", value, "ssRid");
            return (Criteria) this;
        }

        public Criteria andSsRidGreaterThanOrEqualTo(Integer value) {
            addCriterion("ss_rid >=", value, "ssRid");
            return (Criteria) this;
        }

        public Criteria andSsRidLessThan(Integer value) {
            addCriterion("ss_rid <", value, "ssRid");
            return (Criteria) this;
        }

        public Criteria andSsRidLessThanOrEqualTo(Integer value) {
            addCriterion("ss_rid <=", value, "ssRid");
            return (Criteria) this;
        }

        public Criteria andSsRidIn(List<Integer> values) {
            addCriterion("ss_rid in", values, "ssRid");
            return (Criteria) this;
        }

        public Criteria andSsRidNotIn(List<Integer> values) {
            addCriterion("ss_rid not in", values, "ssRid");
            return (Criteria) this;
        }

        public Criteria andSsRidBetween(Integer value1, Integer value2) {
            addCriterion("ss_rid between", value1, value2, "ssRid");
            return (Criteria) this;
        }

        public Criteria andSsRidNotBetween(Integer value1, Integer value2) {
            addCriterion("ss_rid not between", value1, value2, "ssRid");
            return (Criteria) this;
        }

        public Criteria andSsDidIsNull() {
            addCriterion("ss_did is null");
            return (Criteria) this;
        }

        public Criteria andSsDidIsNotNull() {
            addCriterion("ss_did is not null");
            return (Criteria) this;
        }

        public Criteria andSsDidEqualTo(Integer value) {
            addCriterion("ss_did =", value, "ssDid");
            return (Criteria) this;
        }

        public Criteria andSsDidNotEqualTo(Integer value) {
            addCriterion("ss_did <>", value, "ssDid");
            return (Criteria) this;
        }

        public Criteria andSsDidGreaterThan(Integer value) {
            addCriterion("ss_did >", value, "ssDid");
            return (Criteria) this;
        }

        public Criteria andSsDidGreaterThanOrEqualTo(Integer value) {
            addCriterion("ss_did >=", value, "ssDid");
            return (Criteria) this;
        }

        public Criteria andSsDidLessThan(Integer value) {
            addCriterion("ss_did <", value, "ssDid");
            return (Criteria) this;
        }

        public Criteria andSsDidLessThanOrEqualTo(Integer value) {
            addCriterion("ss_did <=", value, "ssDid");
            return (Criteria) this;
        }

        public Criteria andSsDidIn(List<Integer> values) {
            addCriterion("ss_did in", values, "ssDid");
            return (Criteria) this;
        }

        public Criteria andSsDidNotIn(List<Integer> values) {
            addCriterion("ss_did not in", values, "ssDid");
            return (Criteria) this;
        }

        public Criteria andSsDidBetween(Integer value1, Integer value2) {
            addCriterion("ss_did between", value1, value2, "ssDid");
            return (Criteria) this;
        }

        public Criteria andSsDidNotBetween(Integer value1, Integer value2) {
            addCriterion("ss_did not between", value1, value2, "ssDid");
            return (Criteria) this;
        }

        public Criteria andSsRdateIsNull() {
            addCriterion("ss_rdate is null");
            return (Criteria) this;
        }

        public Criteria andSsRdateIsNotNull() {
            addCriterion("ss_rdate is not null");
            return (Criteria) this;
        }

        public Criteria andSsRdateEqualTo(Date value) {
            addCriterion("ss_rdate =", value, "ssRdate");
            return (Criteria) this;
        }

        public Criteria andSsRdateNotEqualTo(Date value) {
            addCriterion("ss_rdate <>", value, "ssRdate");
            return (Criteria) this;
        }

        public Criteria andSsRdateGreaterThan(Date value) {
            addCriterion("ss_rdate >", value, "ssRdate");
            return (Criteria) this;
        }

        public Criteria andSsRdateGreaterThanOrEqualTo(Date value) {
            addCriterion("ss_rdate >=", value, "ssRdate");
            return (Criteria) this;
        }

        public Criteria andSsRdateLessThan(Date value) {
            addCriterion("ss_rdate <", value, "ssRdate");
            return (Criteria) this;
        }

        public Criteria andSsRdateLessThanOrEqualTo(Date value) {
            addCriterion("ss_rdate <=", value, "ssRdate");
            return (Criteria) this;
        }

        public Criteria andSsRdateIn(List<Date> values) {
            addCriterion("ss_rdate in", values, "ssRdate");
            return (Criteria) this;
        }

        public Criteria andSsRdateNotIn(List<Date> values) {
            addCriterion("ss_rdate not in", values, "ssRdate");
            return (Criteria) this;
        }

        public Criteria andSsRdateBetween(Date value1, Date value2) {
            addCriterion("ss_rdate between", value1, value2, "ssRdate");
            return (Criteria) this;
        }

        public Criteria andSsRdateNotBetween(Date value1, Date value2) {
            addCriterion("ss_rdate not between", value1, value2, "ssRdate");
            return (Criteria) this;
        }

        public Criteria andSsRnrIsNull() {
            addCriterion("ss_rnr is null");
            return (Criteria) this;
        }

        public Criteria andSsRnrIsNotNull() {
            addCriterion("ss_rnr is not null");
            return (Criteria) this;
        }

        public Criteria andSsRnrEqualTo(String value) {
            addCriterion("ss_rnr =", value, "ssRnr");
            return (Criteria) this;
        }

        public Criteria andSsRnrNotEqualTo(String value) {
            addCriterion("ss_rnr <>", value, "ssRnr");
            return (Criteria) this;
        }

        public Criteria andSsRnrGreaterThan(String value) {
            addCriterion("ss_rnr >", value, "ssRnr");
            return (Criteria) this;
        }

        public Criteria andSsRnrGreaterThanOrEqualTo(String value) {
            addCriterion("ss_rnr >=", value, "ssRnr");
            return (Criteria) this;
        }

        public Criteria andSsRnrLessThan(String value) {
            addCriterion("ss_rnr <", value, "ssRnr");
            return (Criteria) this;
        }

        public Criteria andSsRnrLessThanOrEqualTo(String value) {
            addCriterion("ss_rnr <=", value, "ssRnr");
            return (Criteria) this;
        }

        public Criteria andSsRnrLike(String value) {
            addCriterion("ss_rnr like", value, "ssRnr");
            return (Criteria) this;
        }

        public Criteria andSsRnrNotLike(String value) {
            addCriterion("ss_rnr not like", value, "ssRnr");
            return (Criteria) this;
        }

        public Criteria andSsRnrIn(List<String> values) {
            addCriterion("ss_rnr in", values, "ssRnr");
            return (Criteria) this;
        }

        public Criteria andSsRnrNotIn(List<String> values) {
            addCriterion("ss_rnr not in", values, "ssRnr");
            return (Criteria) this;
        }

        public Criteria andSsRnrBetween(String value1, String value2) {
            addCriterion("ss_rnr between", value1, value2, "ssRnr");
            return (Criteria) this;
        }

        public Criteria andSsRnrNotBetween(String value1, String value2) {
            addCriterion("ss_rnr not between", value1, value2, "ssRnr");
            return (Criteria) this;
        }

        public Criteria andSsRimageIsNull() {
            addCriterion("ss_rimage is null");
            return (Criteria) this;
        }

        public Criteria andSsRimageIsNotNull() {
            addCriterion("ss_rimage is not null");
            return (Criteria) this;
        }

        public Criteria andSsRimageEqualTo(String value) {
            addCriterion("ss_rimage =", value, "ssRimage");
            return (Criteria) this;
        }

        public Criteria andSsRimageNotEqualTo(String value) {
            addCriterion("ss_rimage <>", value, "ssRimage");
            return (Criteria) this;
        }

        public Criteria andSsRimageGreaterThan(String value) {
            addCriterion("ss_rimage >", value, "ssRimage");
            return (Criteria) this;
        }

        public Criteria andSsRimageGreaterThanOrEqualTo(String value) {
            addCriterion("ss_rimage >=", value, "ssRimage");
            return (Criteria) this;
        }

        public Criteria andSsRimageLessThan(String value) {
            addCriterion("ss_rimage <", value, "ssRimage");
            return (Criteria) this;
        }

        public Criteria andSsRimageLessThanOrEqualTo(String value) {
            addCriterion("ss_rimage <=", value, "ssRimage");
            return (Criteria) this;
        }

        public Criteria andSsRimageLike(String value) {
            addCriterion("ss_rimage like", value, "ssRimage");
            return (Criteria) this;
        }

        public Criteria andSsRimageNotLike(String value) {
            addCriterion("ss_rimage not like", value, "ssRimage");
            return (Criteria) this;
        }

        public Criteria andSsRimageIn(List<String> values) {
            addCriterion("ss_rimage in", values, "ssRimage");
            return (Criteria) this;
        }

        public Criteria andSsRimageNotIn(List<String> values) {
            addCriterion("ss_rimage not in", values, "ssRimage");
            return (Criteria) this;
        }

        public Criteria andSsRimageBetween(String value1, String value2) {
            addCriterion("ss_rimage between", value1, value2, "ssRimage");
            return (Criteria) this;
        }

        public Criteria andSsRimageNotBetween(String value1, String value2) {
            addCriterion("ss_rimage not between", value1, value2, "ssRimage");
            return (Criteria) this;
        }

        public Criteria andSsRstateIsNull() {
            addCriterion("ss_rstate is null");
            return (Criteria) this;
        }

        public Criteria andSsRstateIsNotNull() {
            addCriterion("ss_rstate is not null");
            return (Criteria) this;
        }

        public Criteria andSsRstateEqualTo(String value) {
            addCriterion("ss_rstate =", value, "ssRstate");
            return (Criteria) this;
        }

        public Criteria andSsRstateNotEqualTo(String value) {
            addCriterion("ss_rstate <>", value, "ssRstate");
            return (Criteria) this;
        }

        public Criteria andSsRstateGreaterThan(String value) {
            addCriterion("ss_rstate >", value, "ssRstate");
            return (Criteria) this;
        }

        public Criteria andSsRstateGreaterThanOrEqualTo(String value) {
            addCriterion("ss_rstate >=", value, "ssRstate");
            return (Criteria) this;
        }

        public Criteria andSsRstateLessThan(String value) {
            addCriterion("ss_rstate <", value, "ssRstate");
            return (Criteria) this;
        }

        public Criteria andSsRstateLessThanOrEqualTo(String value) {
            addCriterion("ss_rstate <=", value, "ssRstate");
            return (Criteria) this;
        }

        public Criteria andSsRstateLike(String value) {
            addCriterion("ss_rstate like", value, "ssRstate");
            return (Criteria) this;
        }

        public Criteria andSsRstateNotLike(String value) {
            addCriterion("ss_rstate not like", value, "ssRstate");
            return (Criteria) this;
        }

        public Criteria andSsRstateIn(List<String> values) {
            addCriterion("ss_rstate in", values, "ssRstate");
            return (Criteria) this;
        }

        public Criteria andSsRstateNotIn(List<String> values) {
            addCriterion("ss_rstate not in", values, "ssRstate");
            return (Criteria) this;
        }

        public Criteria andSsRstateBetween(String value1, String value2) {
            addCriterion("ss_rstate between", value1, value2, "ssRstate");
            return (Criteria) this;
        }

        public Criteria andSsRstateNotBetween(String value1, String value2) {
            addCriterion("ss_rstate not between", value1, value2, "ssRstate");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}