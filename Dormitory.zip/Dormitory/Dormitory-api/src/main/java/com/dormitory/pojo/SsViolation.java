package com.dormitory.pojo;

import java.util.Date;

public class SsViolation {
    private Integer ssVid;

    private Integer ssDid;

    private Integer ssUid;

    private Date ssVdate;

    private String ssVthing;

    private String ssVremark;

    private String ssVstate;
    
    private SsUser ssUser;
    
    public SsUser getSsUser() {
		return ssUser;
	}

	public void setSsUser(SsUser ssUser) {
		this.ssUser = ssUser;
	}

	private SsDorm ssDorm;

    public Integer getSsVid() {
        return ssVid;
    }

    public void setSsVid(Integer ssVid) {
        this.ssVid = ssVid;
    }

    public Integer getSsDid() {
        return ssDid;
    }

    public void setSsDid(Integer ssDid) {
        this.ssDid = ssDid;
    }

    public Integer getSsUid() {
        return ssUid;
    }

    public void setSsUid(Integer ssUid) {
        this.ssUid = ssUid;
    }

    public Date getSsVdate() {
        return ssVdate;
    }

    public void setSsVdate(Date ssVdate) {
        this.ssVdate = ssVdate;
    }

    public String getSsVthing() {
        return ssVthing;
    }

    public void setSsVthing(String ssVthing) {
        this.ssVthing = ssVthing == null ? null : ssVthing.trim();
    }

    public String getSsVremark() {
        return ssVremark;
    }

    public void setSsVremark(String ssVremark) {
        this.ssVremark = ssVremark == null ? null : ssVremark.trim();
    }

    public String getSsVstate() {
        return ssVstate;
    }

    public void setSsVstate(String ssVstate) {
        this.ssVstate = ssVstate == null ? null : ssVstate.trim();
    }

	public SsDorm getSsDorm() {
		return ssDorm;
	}

	public void setSsDorm(SsDorm ssDorm) {
		this.ssDorm = ssDorm;
	}

	@Override
	public String toString() {
		return "SsViolation [ssVid=" + ssVid + ", ssDid=" + ssDid + ", ssUid=" + ssUid + ", ssVdate=" + ssVdate
				+ ", ssVthing=" + ssVthing + ", ssVremark=" + ssVremark + ", ssVstate=" + ssVstate + ", ssUser="
				+ ssUser + ", ssDorm=" + ssDorm + "]";
	} 
}