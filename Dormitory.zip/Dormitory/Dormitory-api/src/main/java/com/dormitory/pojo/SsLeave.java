package com.dormitory.pojo;

import java.util.Date;

public class SsLeave {
    private Integer ssLid;

    private Integer ssUid;

    private Date ssLwdate;

    private Date ssLddate;

    private Date ssLbdate;

    private String ssLstatus;
    
    //以对象形式注入
    private SsUser ssUser;
    
    private SsDorm ssDorm;

	public Integer getSsLid() {
		return ssLid;
	}

	public void setSsLid(Integer ssLid) {
		this.ssLid = ssLid;
	}

	public Integer getSsUid() {
		return ssUid;
	}

	public void setSsUid(Integer ssUid) {
		this.ssUid = ssUid;
	}

	public Date getSsLwdate() {
		return ssLwdate;
	}

	public void setSsLwdate(Date ssLwdate) {
		this.ssLwdate = ssLwdate;
	}

	public Date getSsLddate() {
		return ssLddate;
	}

	public void setSsLddate(Date ssLddate) {
		this.ssLddate = ssLddate;
	}

	public Date getSsLbdate() {
		return ssLbdate;
	}

	public void setSsLbdate(Date ssLbdate) {
		this.ssLbdate = ssLbdate;
	}

	public String getSsLstatus() {
		return ssLstatus;
	}

	public void setSsLstatus(String ssLstatus) {
		this.ssLstatus = ssLstatus;
	}

	public SsUser getSsUser() {
		return ssUser;
	}

	public void setSsUser(SsUser ssUser) {
		this.ssUser = ssUser;
	}

	public SsDorm getSsDorm() {
		return ssDorm;
	}

	public void setSsDorm(SsDorm ssDorm) {
		this.ssDorm = ssDorm;
	}

	@Override
	public String toString() {
		return "SsLeave [ssLid=" + ssLid + ", ssUid=" + ssUid + ", ssLwdate=" + ssLwdate + ", ssLddate=" + ssLddate
				+ ", ssLbdate=" + ssLbdate + ", ssLstatus=" + ssLstatus + ", ssUser=" + ssUser + ", ssDorm=" + ssDorm
				+ "]";
	}

  
}