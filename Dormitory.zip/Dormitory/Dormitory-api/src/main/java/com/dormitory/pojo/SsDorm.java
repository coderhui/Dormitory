package com.dormitory.pojo;

public class SsDorm {
    private Integer ssDid;

    private String ssDname;
    
    private SsUser ssUser;

    public Integer getSsDid() {
        return ssDid;
    }

    public SsUser getSsUser() {
		return ssUser;
	}

	public void setSsUser(SsUser ssUser) {
		this.ssUser = ssUser;
	}

	public void setSsDid(Integer ssDid) {
        this.ssDid = ssDid;
    }

    public String getSsDname() {
        return ssDname;
    }

    public void setSsDname(String ssDname) {
        this.ssDname = ssDname == null ? null : ssDname.trim();
    }

	@Override
	public String toString() {
		return "SsDorm [ssDid=" + ssDid + ", ssDname=" + ssDname + ", ssUser=" + ssUser + "]";
	}
    
}