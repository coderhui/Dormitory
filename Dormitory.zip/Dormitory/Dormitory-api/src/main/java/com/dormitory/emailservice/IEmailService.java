package com.dormitory.emailservice;

public interface IEmailService {
	//发送简单的邮件
		void sendSimpleEmail(String sendTo,String title,String content);
}
