package com.dormitory.emailservice.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.dormitory.config.emailConfig;
import com.dormitory.emailservice.IEmailService;
@Service
public class EmailServiceImpl implements IEmailService {
	@Autowired
	private JavaMailSender JMLsend;
	
	@Autowired
	private emailConfig EmailFrom;
	
	@Override
	public void sendSimpleEmail(String sendTo, String title, String content) {
		// TODO Auto-generated method stub
		SimpleMailMessage message = new SimpleMailMessage();
		message.setFrom(EmailFrom.getEmailFrom());
		message.setTo(sendTo);  //设置邮件接收方
		message.setSubject(title);  //设置邮件标题
		message.setText(content);  //设置邮件内容
		JMLsend.send(message);
	}

}
