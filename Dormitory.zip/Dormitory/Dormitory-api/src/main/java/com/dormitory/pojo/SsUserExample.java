package com.dormitory.pojo;

import java.util.ArrayList;
import java.util.List;

public class SsUserExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public SsUserExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andSsUidIsNull() {
            addCriterion("ss_uid is null");
            return (Criteria) this;
        }

        public Criteria andSsUidIsNotNull() {
            addCriterion("ss_uid is not null");
            return (Criteria) this;
        }

        public Criteria andSsUidEqualTo(Integer value) {
            addCriterion("ss_uid =", value, "ssUid");
            return (Criteria) this;
        }

        public Criteria andSsUidNotEqualTo(Integer value) {
            addCriterion("ss_uid <>", value, "ssUid");
            return (Criteria) this;
        }

        public Criteria andSsUidGreaterThan(Integer value) {
            addCriterion("ss_uid >", value, "ssUid");
            return (Criteria) this;
        }

        public Criteria andSsUidGreaterThanOrEqualTo(Integer value) {
            addCriterion("ss_uid >=", value, "ssUid");
            return (Criteria) this;
        }

        public Criteria andSsUidLessThan(Integer value) {
            addCriterion("ss_uid <", value, "ssUid");
            return (Criteria) this;
        }

        public Criteria andSsUidLessThanOrEqualTo(Integer value) {
            addCriterion("ss_uid <=", value, "ssUid");
            return (Criteria) this;
        }

        public Criteria andSsUidIn(List<Integer> values) {
            addCriterion("ss_uid in", values, "ssUid");
            return (Criteria) this;
        }

        public Criteria andSsUidNotIn(List<Integer> values) {
            addCriterion("ss_uid not in", values, "ssUid");
            return (Criteria) this;
        }

        public Criteria andSsUidBetween(Integer value1, Integer value2) {
            addCriterion("ss_uid between", value1, value2, "ssUid");
            return (Criteria) this;
        }

        public Criteria andSsUidNotBetween(Integer value1, Integer value2) {
            addCriterion("ss_uid not between", value1, value2, "ssUid");
            return (Criteria) this;
        }

        public Criteria andSsUnameIsNull() {
            addCriterion("ss_uname is null");
            return (Criteria) this;
        }

        public Criteria andSsUnameIsNotNull() {
            addCriterion("ss_uname is not null");
            return (Criteria) this;
        }

        public Criteria andSsUnameEqualTo(String value) {
            addCriterion("ss_uname =", value, "ssUname");
            return (Criteria) this;
        }

        public Criteria andSsUnameNotEqualTo(String value) {
            addCriterion("ss_uname <>", value, "ssUname");
            return (Criteria) this;
        }

        public Criteria andSsUnameGreaterThan(String value) {
            addCriterion("ss_uname >", value, "ssUname");
            return (Criteria) this;
        }

        public Criteria andSsUnameGreaterThanOrEqualTo(String value) {
            addCriterion("ss_uname >=", value, "ssUname");
            return (Criteria) this;
        }

        public Criteria andSsUnameLessThan(String value) {
            addCriterion("ss_uname <", value, "ssUname");
            return (Criteria) this;
        }

        public Criteria andSsUnameLessThanOrEqualTo(String value) {
            addCriterion("ss_uname <=", value, "ssUname");
            return (Criteria) this;
        }

        public Criteria andSsUnameLike(String value) {
            addCriterion("ss_uname like", value, "ssUname");
            return (Criteria) this;
        }

        public Criteria andSsUnameNotLike(String value) {
            addCriterion("ss_uname not like", value, "ssUname");
            return (Criteria) this;
        }

        public Criteria andSsUnameIn(List<String> values) {
            addCriterion("ss_uname in", values, "ssUname");
            return (Criteria) this;
        }

        public Criteria andSsUnameNotIn(List<String> values) {
            addCriterion("ss_uname not in", values, "ssUname");
            return (Criteria) this;
        }

        public Criteria andSsUnameBetween(String value1, String value2) {
            addCriterion("ss_uname between", value1, value2, "ssUname");
            return (Criteria) this;
        }

        public Criteria andSsUnameNotBetween(String value1, String value2) {
            addCriterion("ss_uname not between", value1, value2, "ssUname");
            return (Criteria) this;
        }

        public Criteria andSsPasswordIsNull() {
            addCriterion("ss_password is null");
            return (Criteria) this;
        }

        public Criteria andSsPasswordIsNotNull() {
            addCriterion("ss_password is not null");
            return (Criteria) this;
        }

        public Criteria andSsPasswordEqualTo(String value) {
            addCriterion("ss_password =", value, "ssPassword");
            return (Criteria) this;
        }

        public Criteria andSsPasswordNotEqualTo(String value) {
            addCriterion("ss_password <>", value, "ssPassword");
            return (Criteria) this;
        }

        public Criteria andSsPasswordGreaterThan(String value) {
            addCriterion("ss_password >", value, "ssPassword");
            return (Criteria) this;
        }

        public Criteria andSsPasswordGreaterThanOrEqualTo(String value) {
            addCriterion("ss_password >=", value, "ssPassword");
            return (Criteria) this;
        }

        public Criteria andSsPasswordLessThan(String value) {
            addCriterion("ss_password <", value, "ssPassword");
            return (Criteria) this;
        }

        public Criteria andSsPasswordLessThanOrEqualTo(String value) {
            addCriterion("ss_password <=", value, "ssPassword");
            return (Criteria) this;
        }

        public Criteria andSsPasswordLike(String value) {
            addCriterion("ss_password like", value, "ssPassword");
            return (Criteria) this;
        }

        public Criteria andSsPasswordNotLike(String value) {
            addCriterion("ss_password not like", value, "ssPassword");
            return (Criteria) this;
        }

        public Criteria andSsPasswordIn(List<String> values) {
            addCriterion("ss_password in", values, "ssPassword");
            return (Criteria) this;
        }

        public Criteria andSsPasswordNotIn(List<String> values) {
            addCriterion("ss_password not in", values, "ssPassword");
            return (Criteria) this;
        }

        public Criteria andSsPasswordBetween(String value1, String value2) {
            addCriterion("ss_password between", value1, value2, "ssPassword");
            return (Criteria) this;
        }

        public Criteria andSsPasswordNotBetween(String value1, String value2) {
            addCriterion("ss_password not between", value1, value2, "ssPassword");
            return (Criteria) this;
        }

        public Criteria andSsSexIsNull() {
            addCriterion("ss_sex is null");
            return (Criteria) this;
        }

        public Criteria andSsSexIsNotNull() {
            addCriterion("ss_sex is not null");
            return (Criteria) this;
        }

        public Criteria andSsSexEqualTo(String value) {
            addCriterion("ss_sex =", value, "ssSex");
            return (Criteria) this;
        }

        public Criteria andSsSexNotEqualTo(String value) {
            addCriterion("ss_sex <>", value, "ssSex");
            return (Criteria) this;
        }

        public Criteria andSsSexGreaterThan(String value) {
            addCriterion("ss_sex >", value, "ssSex");
            return (Criteria) this;
        }

        public Criteria andSsSexGreaterThanOrEqualTo(String value) {
            addCriterion("ss_sex >=", value, "ssSex");
            return (Criteria) this;
        }

        public Criteria andSsSexLessThan(String value) {
            addCriterion("ss_sex <", value, "ssSex");
            return (Criteria) this;
        }

        public Criteria andSsSexLessThanOrEqualTo(String value) {
            addCriterion("ss_sex <=", value, "ssSex");
            return (Criteria) this;
        }

        public Criteria andSsSexLike(String value) {
            addCriterion("ss_sex like", value, "ssSex");
            return (Criteria) this;
        }

        public Criteria andSsSexNotLike(String value) {
            addCriterion("ss_sex not like", value, "ssSex");
            return (Criteria) this;
        }

        public Criteria andSsSexIn(List<String> values) {
            addCriterion("ss_sex in", values, "ssSex");
            return (Criteria) this;
        }

        public Criteria andSsSexNotIn(List<String> values) {
            addCriterion("ss_sex not in", values, "ssSex");
            return (Criteria) this;
        }

        public Criteria andSsSexBetween(String value1, String value2) {
            addCriterion("ss_sex between", value1, value2, "ssSex");
            return (Criteria) this;
        }

        public Criteria andSsSexNotBetween(String value1, String value2) {
            addCriterion("ss_sex not between", value1, value2, "ssSex");
            return (Criteria) this;
        }

        public Criteria andSsClassIsNull() {
            addCriterion("ss_class is null");
            return (Criteria) this;
        }

        public Criteria andSsClassIsNotNull() {
            addCriterion("ss_class is not null");
            return (Criteria) this;
        }

        public Criteria andSsClassEqualTo(String value) {
            addCriterion("ss_class =", value, "ssClass");
            return (Criteria) this;
        }

        public Criteria andSsClassNotEqualTo(String value) {
            addCriterion("ss_class <>", value, "ssClass");
            return (Criteria) this;
        }

        public Criteria andSsClassGreaterThan(String value) {
            addCriterion("ss_class >", value, "ssClass");
            return (Criteria) this;
        }

        public Criteria andSsClassGreaterThanOrEqualTo(String value) {
            addCriterion("ss_class >=", value, "ssClass");
            return (Criteria) this;
        }

        public Criteria andSsClassLessThan(String value) {
            addCriterion("ss_class <", value, "ssClass");
            return (Criteria) this;
        }

        public Criteria andSsClassLessThanOrEqualTo(String value) {
            addCriterion("ss_class <=", value, "ssClass");
            return (Criteria) this;
        }

        public Criteria andSsClassLike(String value) {
            addCriterion("ss_class like", value, "ssClass");
            return (Criteria) this;
        }

        public Criteria andSsClassNotLike(String value) {
            addCriterion("ss_class not like", value, "ssClass");
            return (Criteria) this;
        }

        public Criteria andSsClassIn(List<String> values) {
            addCriterion("ss_class in", values, "ssClass");
            return (Criteria) this;
        }

        public Criteria andSsClassNotIn(List<String> values) {
            addCriterion("ss_class not in", values, "ssClass");
            return (Criteria) this;
        }

        public Criteria andSsClassBetween(String value1, String value2) {
            addCriterion("ss_class between", value1, value2, "ssClass");
            return (Criteria) this;
        }

        public Criteria andSsClassNotBetween(String value1, String value2) {
            addCriterion("ss_class not between", value1, value2, "ssClass");
            return (Criteria) this;
        }

        public Criteria andSsEmailIsNull() {
            addCriterion("ss_email is null");
            return (Criteria) this;
        }

        public Criteria andSsEmailIsNotNull() {
            addCriterion("ss_email is not null");
            return (Criteria) this;
        }

        public Criteria andSsEmailEqualTo(String value) {
            addCriterion("ss_email =", value, "ssEmail");
            return (Criteria) this;
        }

        public Criteria andSsEmailNotEqualTo(String value) {
            addCriterion("ss_email <>", value, "ssEmail");
            return (Criteria) this;
        }

        public Criteria andSsEmailGreaterThan(String value) {
            addCriterion("ss_email >", value, "ssEmail");
            return (Criteria) this;
        }

        public Criteria andSsEmailGreaterThanOrEqualTo(String value) {
            addCriterion("ss_email >=", value, "ssEmail");
            return (Criteria) this;
        }

        public Criteria andSsEmailLessThan(String value) {
            addCriterion("ss_email <", value, "ssEmail");
            return (Criteria) this;
        }

        public Criteria andSsEmailLessThanOrEqualTo(String value) {
            addCriterion("ss_email <=", value, "ssEmail");
            return (Criteria) this;
        }

        public Criteria andSsEmailLike(String value) {
            addCriterion("ss_email like", value, "ssEmail");
            return (Criteria) this;
        }

        public Criteria andSsEmailNotLike(String value) {
            addCriterion("ss_email not like", value, "ssEmail");
            return (Criteria) this;
        }

        public Criteria andSsEmailIn(List<String> values) {
            addCriterion("ss_email in", values, "ssEmail");
            return (Criteria) this;
        }

        public Criteria andSsEmailNotIn(List<String> values) {
            addCriterion("ss_email not in", values, "ssEmail");
            return (Criteria) this;
        }

        public Criteria andSsEmailBetween(String value1, String value2) {
            addCriterion("ss_email between", value1, value2, "ssEmail");
            return (Criteria) this;
        }

        public Criteria andSsEmailNotBetween(String value1, String value2) {
            addCriterion("ss_email not between", value1, value2, "ssEmail");
            return (Criteria) this;
        }

        public Criteria andSsDidIsNull() {
            addCriterion("ss_did is null");
            return (Criteria) this;
        }

        public Criteria andSsDidIsNotNull() {
            addCriterion("ss_did is not null");
            return (Criteria) this;
        }

        public Criteria andSsDidEqualTo(Integer value) {
            addCriterion("ss_did =", value, "ssDid");
            return (Criteria) this;
        }

        public Criteria andSsDidNotEqualTo(Integer value) {
            addCriterion("ss_did <>", value, "ssDid");
            return (Criteria) this;
        }

        public Criteria andSsDidGreaterThan(Integer value) {
            addCriterion("ss_did >", value, "ssDid");
            return (Criteria) this;
        }

        public Criteria andSsDidGreaterThanOrEqualTo(Integer value) {
            addCriterion("ss_did >=", value, "ssDid");
            return (Criteria) this;
        }

        public Criteria andSsDidLessThan(Integer value) {
            addCriterion("ss_did <", value, "ssDid");
            return (Criteria) this;
        }

        public Criteria andSsDidLessThanOrEqualTo(Integer value) {
            addCriterion("ss_did <=", value, "ssDid");
            return (Criteria) this;
        }

        public Criteria andSsDidIn(List<Integer> values) {
            addCriterion("ss_did in", values, "ssDid");
            return (Criteria) this;
        }

        public Criteria andSsDidNotIn(List<Integer> values) {
            addCriterion("ss_did not in", values, "ssDid");
            return (Criteria) this;
        }

        public Criteria andSsDidBetween(Integer value1, Integer value2) {
            addCriterion("ss_did between", value1, value2, "ssDid");
            return (Criteria) this;
        }

        public Criteria andSsDidNotBetween(Integer value1, Integer value2) {
            addCriterion("ss_did not between", value1, value2, "ssDid");
            return (Criteria) this;
        }

        public Criteria andSsMoneyIsNull() {
            addCriterion("ss_money is null");
            return (Criteria) this;
        }

        public Criteria andSsMoneyIsNotNull() {
            addCriterion("ss_money is not null");
            return (Criteria) this;
        }

        public Criteria andSsMoneyEqualTo(Double value) {
            addCriterion("ss_money =", value, "ssMoney");
            return (Criteria) this;
        }

        public Criteria andSsMoneyNotEqualTo(Double value) {
            addCriterion("ss_money <>", value, "ssMoney");
            return (Criteria) this;
        }

        public Criteria andSsMoneyGreaterThan(Double value) {
            addCriterion("ss_money >", value, "ssMoney");
            return (Criteria) this;
        }

        public Criteria andSsMoneyGreaterThanOrEqualTo(Double value) {
            addCriterion("ss_money >=", value, "ssMoney");
            return (Criteria) this;
        }

        public Criteria andSsMoneyLessThan(Double value) {
            addCriterion("ss_money <", value, "ssMoney");
            return (Criteria) this;
        }

        public Criteria andSsMoneyLessThanOrEqualTo(Double value) {
            addCriterion("ss_money <=", value, "ssMoney");
            return (Criteria) this;
        }

        public Criteria andSsMoneyIn(List<Double> values) {
            addCriterion("ss_money in", values, "ssMoney");
            return (Criteria) this;
        }

        public Criteria andSsMoneyNotIn(List<Double> values) {
            addCriterion("ss_money not in", values, "ssMoney");
            return (Criteria) this;
        }

        public Criteria andSsMoneyBetween(Double value1, Double value2) {
            addCriterion("ss_money between", value1, value2, "ssMoney");
            return (Criteria) this;
        }

        public Criteria andSsMoneyNotBetween(Double value1, Double value2) {
            addCriterion("ss_money not between", value1, value2, "ssMoney");
            return (Criteria) this;
        }

        public Criteria andSsPowerIsNull() {
            addCriterion("ss_power is null");
            return (Criteria) this;
        }

        public Criteria andSsPowerIsNotNull() {
            addCriterion("ss_power is not null");
            return (Criteria) this;
        }

        public Criteria andSsPowerEqualTo(Integer value) {
            addCriterion("ss_power =", value, "ssPower");
            return (Criteria) this;
        }

        public Criteria andSsPowerNotEqualTo(Integer value) {
            addCriterion("ss_power <>", value, "ssPower");
            return (Criteria) this;
        }

        public Criteria andSsPowerGreaterThan(Integer value) {
            addCriterion("ss_power >", value, "ssPower");
            return (Criteria) this;
        }

        public Criteria andSsPowerGreaterThanOrEqualTo(Integer value) {
            addCriterion("ss_power >=", value, "ssPower");
            return (Criteria) this;
        }

        public Criteria andSsPowerLessThan(Integer value) {
            addCriterion("ss_power <", value, "ssPower");
            return (Criteria) this;
        }

        public Criteria andSsPowerLessThanOrEqualTo(Integer value) {
            addCriterion("ss_power <=", value, "ssPower");
            return (Criteria) this;
        }

        public Criteria andSsPowerIn(List<Integer> values) {
            addCriterion("ss_power in", values, "ssPower");
            return (Criteria) this;
        }

        public Criteria andSsPowerNotIn(List<Integer> values) {
            addCriterion("ss_power not in", values, "ssPower");
            return (Criteria) this;
        }

        public Criteria andSsPowerBetween(Integer value1, Integer value2) {
            addCriterion("ss_power between", value1, value2, "ssPower");
            return (Criteria) this;
        }

        public Criteria andSsPowerNotBetween(Integer value1, Integer value2) {
            addCriterion("ss_power not between", value1, value2, "ssPower");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}