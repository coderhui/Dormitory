package com.dormitory.pojo;

public class SsWaterandelectricity {
    private Integer ssWeid;

    private Integer ssDid;

    private Integer ssEnum;

    private Integer ssWnum;

    private Double ssMoney;

    private String ssWestate;
    
    //以对象形式注入
    private SsDorm ssDorms;
    
    private SsUser ssUser;

    public SsUser getSsUser() {
		return ssUser;
	}

	public void setSsUser(SsUser ssUser) {
		this.ssUser = ssUser;
	}

	public Integer getSsWeid() {
        return ssWeid;
    }

    public void setSsWeid(Integer ssWeid) {
        this.ssWeid = ssWeid;
    }

    public Integer getSsDid() {
        return ssDid;
    }

    public void setSsDid(Integer ssDid) {
        this.ssDid = ssDid;
    }

    public Integer getSsEnum() {
        return ssEnum;
    }

    public void setSsEnum(Integer ssEnum) {
        this.ssEnum = ssEnum;
    }

    public Integer getSsWnum() {
        return ssWnum;
    }

    public void setSsWnum(Integer ssWnum) {
        this.ssWnum = ssWnum;
    }

    public Double getSsMoney() {
        return ssMoney;
    }

    public void setSsMoney(Double ssMoney) {
        this.ssMoney = ssMoney;
    }

    public String getSsWestate() {
        return ssWestate;
    }

    public void setSsWestate(String ssWestate) {
        this.ssWestate = ssWestate == null ? null : ssWestate.trim();
    }

	public SsDorm getSsDorms() {
		return ssDorms;
	}

	public void setSsDorms(SsDorm ssDorms) {
		this.ssDorms = ssDorms;
	}

	@Override
	public String toString() {
		return "SsWaterandelectricity [ssWeid=" + ssWeid + ", ssDid=" + ssDid + ", ssEnum=" + ssEnum + ", ssWnum="
				+ ssWnum + ", ssMoney=" + ssMoney + ", ssWestate=" + ssWestate + ", ssDorms=" + ssDorms + "]";
	}
    
}