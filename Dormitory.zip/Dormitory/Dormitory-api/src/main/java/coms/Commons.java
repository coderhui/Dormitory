package coms;

public class Commons {
	//服务器
	public static final String pic ="http://localhost:8083/FileServer";
	
	//收水钱老师的uid
	public static final int water_uid = 4;
	
	//一桶水的价格
	public static final double water_price = 8.5;
	
	//送上门一次多少钱
	public static final double water_to_price = 2.0;
}
